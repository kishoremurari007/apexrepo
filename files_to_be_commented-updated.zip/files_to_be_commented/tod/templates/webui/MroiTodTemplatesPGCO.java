package mroi.oracle.apps.xxmro.tod.templates.webui;
/*====================================================================================
|  Name:                MroiTodTemplatesPGCO.java
|  Object Type:         Java Class
|  Description:         TOD Templates Page Controller 
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
|  
|  
|  
======================================================================================*/

import java.io.Serializable;

import mroi.oracle.apps.xxmro.tod.rules.util.MroiTodAWSRuleUtil;
import mroi.oracle.apps.xxmro.tod.templates.util.MroiTodTemplateUtil;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;


/**
 * Controller for ...
 */
public class MroiTodTemplatesPGCO extends OAControllerImpl
{
  public static final String RCS_ID = 
	"$Header: MroiTodTemplatesPGCO.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";

  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.templates.webui");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    
      String successMsg = 
          pageContext.getParameter(MroiTodTemplateUtil.MROI_TOD_TEMPLATE_PARAM_SUCCESS_MSG);

      if (successMsg != null) {
          OAException e = 
              new OAException(successMsg, OAException.CONFIRMATION);
          pageContext.putDialogMessage(e);
          pageContext.removeParameter(MroiTodTemplateUtil.MROI_TOD_TEMPLATE_PARAM_SUCCESS_MSG);
      }

      OAApplicationModule am = pageContext.getApplicationModule(webBean);
      am.invokeMethod("initViewObjects");
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
      String event = pageContext.getParameter(EVENT_PARAM);
      String source = pageContext.getParameter(SOURCE_PARAM);
      String rowReference = pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
      
      if (pageContext.getParameter("SubmitBtn") != null) {
          am.invokeMethod("submit");
          pageContext.putParameter(MroiTodTemplateUtil.MROI_TOD_TEMPLATE_PARAM_SUCCESS_MSG, 
                                   "Successfully saved TOD Templates data.");
          pageContext.forwardImmediatelyToCurrentPage(null, true, "Y");

      } else if (pageContext.getParameter("CancelBtn") != null) {
          pageContext.forwardImmediatelyToCurrentPage(null, false, "N");
      } else if("AddTemplateRow".equals(event)) {
          am.invokeMethod("addTemplateRow");
      } else if("RemoveTemplateRow".equals(event)) {
          Serializable param[] = { rowReference };
          am.invokeMethod("removeTemplateRow", param);
      }
  }

}
