package mroi.oracle.apps.xxmro.tod.webui;
/*====================================================================================
|  Name:                MroiTodReviewCO.java
|  Object Type:         Java Class
|  Description:         TOD Review Page Controller
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
|  
|  
|  
======================================================================================*/
import com.sun.java.util.collections.HashMap;

import java.io.Serializable;

import mroi.oracle.apps.xxmro.tod.server.MroiTodReviewAMImpl;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;


/**
 * Controller for ...
 */
public class MroiTodReviewCO extends OAControllerImpl
{
  public static final String RCS_ID = 
	"$Header: MroiTodReviewCO.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";

  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.webui");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    String PersonIdStr = pageContext.getParameter("PersonId");
    String TodIDStr = pageContext.getParameter("TimePeriodId");
    MroiTodReviewAMImpl MroiTodReviewAM = (MroiTodReviewAMImpl) pageContext.getApplicationModule(webBean);
    Serializable param[] = {PersonIdStr,TodIDStr};
    MroiTodReviewAM.invokeMethod("initMroiTodReviewVO",param);  
    //throw new OAException("PersonId: "+PersonIdStr+" TodID: "+TodIDStr, OAException.INFORMATION);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      if (pageContext.getParameter("Search")!=null) {
          pageContext.setForwardURL("OA.jsp?page=/mroi/oracle/apps/xxmro/tod/webui/MroiTodSearchPG",
                                    null,
                                    OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                    null,
                                    null,
                                    true,
                                    OAWebBeanConstants.ADD_BREAD_CRUMB_YES,
                                    OAWebBeanConstants.IGNORE_MESSAGES);
      }
          
          
      }
    

}
