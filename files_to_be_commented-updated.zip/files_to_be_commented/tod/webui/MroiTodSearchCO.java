package mroi.oracle.apps.xxmro.tod.webui;
/*====================================================================================
|  Name:                MroiTodSearchCO.java
|  Object Type:         Java Class
|  Description:         TOD Search controller
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
|  
|  
|  
======================================================================================*/

import com.sun.java.util.collections.HashMap;

import com.sun.rowset.internal.Row;

import java.io.Serializable;

import mroi.oracle.apps.xxmro.tod.server.MroiTodSearchVOImpl;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

/**
 * Controller for ...
 */
public class MroiTodSearchCO extends OAControllerImpl
{
public static final String RCS_ID = 
	"$Header: MroiTodSearchCO.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";

  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.webui");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    
      if (pageContext.getParameter("Go")!= null) {
        String empname = pageContext.getParameter("EmpName");
        String empnumber = pageContext.getParameter("EmpNumber");
        String todstatus = pageContext.getParameter("TodStatus");
        String todstartdate = pageContext.getParameter("TodStartDate");
        String todenddate = pageContext.getParameter("TodEndDate");
        String todShopName = pageContext.getParameter("TodShopName");
        String todSupervisorName = pageContext.getParameter("TodShopSupervisorName");
        Serializable param[] = {empname,empnumber,todstatus,todstartdate,todenddate, todShopName, todSupervisorName};
        am.invokeMethod("TodSrchQry",param);
      }     
      
      if (pageContext.getParameter("Clear")!= null) {
      pageContext.forwardImmediatelyToCurrentPage(null,false,null);         
      }
  }

}
