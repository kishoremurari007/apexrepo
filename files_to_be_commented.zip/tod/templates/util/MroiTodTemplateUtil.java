package mroi.oracle.apps.xxmro.tod.templates.util;

public class MroiTodTemplateUtil {

    public static final String MROI_TOD_TEMPLATE_STATUS_ACTIVE = "Active";
    public static final String MROI_TOD_TEMPLATE_PARAM_SUCCESS_MSG = "SuccessMsg";
    public static final String MROI_TOD_TEMPLATE_ID_SEQ_NAME = "MROI_OTL_TOD_TEMPLATES_S";
}
