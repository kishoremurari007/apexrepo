from django.conf import settings
import json
from time import sleep
import os
import requests

from .uspslogger import printlog

# Fetch Access Token


def fetch_access_token():
    return get_access_token(str(settings.AZURE_TENANT_ID), str(settings.AZURE_CLIENT_ID), str(settings.AZURE_CLIENT_SECRET))

# Fetch Invitation Access Token


def fetch_invitation_access_token():
    return get_access_token(str(settings.AZURE_TENANT_ID), str(settings.AZURE_INVITATION_CLIENT_ID), str(settings.AZURE_INVITATION_CLIENT_SECRET))

# Get Access Token - Called by fetch_access_token and fetch_invitation_access_token only


def get_access_token(tenant_id, client_id, client_secret):
    #    global G_ACCESS_TOKEN
    scope = 'https://graph.microsoft.com/.default'
    grant_type = 'client_credentials'
    token_url = 'https://login.microsoftonline.com/'+tenant_id+'/oauth2/v2.0/token'
    request_header = {'Content-Type': 'application/x-www-form-urlencoded'}
    request_body = {
        "client_id": client_id,
        "grant_type": grant_type,
        "client_secret": client_secret,
        "scope": scope
    }

    response = requests.post(
        token_url, data=request_body, headers=request_header)
    access_token_json = response.json()
    access_token = ''
    if not response.ok:
        if "error" in access_token_json:
            printlog(access_token_json["error"]["code"])
            printlog(response.status_code)
    else:
        if "access_token" in access_token_json:
            access_token = access_token_json["access_token"]
 #           G_ACCESS_TOKEN = access_token

    return access_token

# Get User ID for a given Email Address


def get_user_id(email, access_token):
    url = 'https://graph.microsoft.com/v1.0/users'
    req_params = {'$select': 'id', '$filter': 'mail eq \''+email+'\''}
    req_header = {'Authorization': 'Bearer ' + access_token}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    user_id = ''
    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        printlog('User Check Result')
        printlog(response_json)
        try:
            user_id = response_json['value'][0]['id']

        except Exception as e:
            user_id = ''

    return user_id

# Send User Invitation


def invite_user(email, display_name, redirect_url, access_token):

    url = 'https://graph.microsoft.com/v1.0/invitations'
    email_message_body = "Hello "+display_name + ", \r\n\r"\
        "Welcome to USPS Logistics Gateway registration. To complete your registration process, select the secure invitation link below. Once logged in, click \"Supplier/Contract Management\" to access the Registration.\r\n\r" + \
        "Need Help?\r\n\r" + \
        "If you have questions, please contact USPS Integrated Logistics EcoSystem (ILE) TMS Support at ILETMSSupport@usps.gov.\r\n\r" + \
        "The United States Postal Service appreciates your business."
    req_body = {
        "invitedUserEmailAddress": email,
        "invitedUserDisplayName": display_name,
        "inviteRedirectUrl": redirect_url,
        "sendInvitationMessage": True,
        "invitedUserMessageInfo": {
            "customizedMessageBody": email_message_body
        }
    }
    printlog(req_body)
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    response = requests.post(url, json=req_body, headers=req_header)
    printlog(requests)
    response_json = response.json()
    user_id = ''
    printlog('Invitation Result')
    printlog(response_json)
    if not response.ok:
        printlog('Invitation Fail')
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        printlog('Invitation Pass')
        printlog(response_json)
        try:
            user_id = response_json['invitedUser']['id']
        except Exception as e:
            user_id = ''

    return user_id

# Update User Details


def update_user_details(user_id, given_name, surname, company_name, bpg_grp_id, extension_attributes, access_token):

    printlog('update_user_details user_id:'+user_id)
    url = 'https://graph.microsoft.com/v1.0/users/'+user_id
    return_message = ""

    req_body = {
        "givenName": given_name,
        "surname": surname,
        "companyName": company_name
    }

    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    # Try N times to Update User
    for count in range(int(settings.AZURE_API_RETRY_COUNT)):
        printlog("Updating User: Iteration#"+str(count))
        response = requests.patch(url, json=req_body, headers=req_header)        
        printlog(response)

        if (response.status_code < 200 or response.status_code > 229):
            printlog('User Update Fail')
            try:
                printlog(response.json())
            except Exception as e:
                printlog('Exception while parsing JSON')
            return_message = 'Error in Updating User'
        else:
            printlog('User Update Pass')
            if bpg_grp_id != "":
                add_to_group(user_id, bpg_grp_id, access_token)
            return_message = 'User Update Passed'
            break
        sleep(int(settings.AZURE_API_WAIT))

    if len(extension_attributes) > 0: #If Extension Attribute needs to be updated
        req_body = extension_attributes
    # Try N times to Update Extension Attribute
        for count in range(int(settings.AZURE_API_RETRY_COUNT)):
            printlog("Updating Extension Attribute: Iteration#"+str(count))
            response = requests.patch(url, json=req_body, headers=req_header)                    
            printlog(response)

            if (response.status_code < 200 or response.status_code > 229):
                printlog('Extension Attribute Update Fail')
                try:
                    printlog(response.json())
                except Exception as e:
                    printlog('Exception while parsing JSON')
                return_message = 'Error in Updating User'
            else:
                printlog('Extension Attribute Update Pass')                
                return_message = 'Extension Attribute Update Passed'
                break
            sleep(int(settings.AZURE_API_WAIT))
    return return_message


def get_bpg_group_id(BPG_GRP_NAME, access_token):
    url = 'https://graph.microsoft.com/v1.0/groups'
    req_params = {'$select': 'id',
                  '$filter': 'displayName eq \''+BPG_GRP_NAME+'\''}
    req_header = {'Authorization': 'Bearer ' + access_token}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    bpg_grp_id = ''
    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        printlog('Group Check Result')
        printlog(response_json)
        try:
            bpg_grp_id = response_json['value'][0]['id']

        except Exception as e:
            bpg_grp_id = ''

    return bpg_grp_id


def add_to_group(user_id, bpg_grp_id, access_token):
    printlog('Adding User to Group')
    url = 'https://graph.microsoft.com/v1.0/groups/'+bpg_grp_id+'/members/$ref'

    req_body = {
        "@odata.id": "https://graph.microsoft.com/v1.0/directoryObjects/"+user_id,
    }

    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    response = requests.post(url, json=req_body, headers=req_header)
    printlog('Sent Data')
    printlog(response)

    printlog('Group Update Result')
    if (response.status_code < 200 or response.status_code > 229):
        printlog('Add Group Failed')
        try:
            printlog(response.json())
        except Exception as e:
            printlog('Exception while parsing JSON')

        '''if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)'''
        return 'Error in Adding User to Group'
    else:
        printlog('Group Add Pass')
    return 'Added to Group'

# Check if User Exists or Not


def does_user_exists(user_details, access_token):

    user_id = get_user_id(user_details.workEmail, access_token)
    if user_id != '':
        printlog('User ID is ' + str(user_id))
        user_details.responseText = 'User is already registered'
        user_details.user_id = user_id
    return user_details

# Send Invitation to User - Wrapper Function


def send_invitation_to_user(user_details, access_token):
    redirectUrl = settings.WEBSITE_URL
    user_details.user_id = invite_user(user_details.workEmail, user_details.firstName +
                                       ' '+user_details.lastName,  redirectUrl, access_token)
    if (user_details.user_id == ''):
        user_details.responseText = 'User Invitation Failed. Please contact administrator.'
    return user_details

# Get List of Groups IDs


def get_group_id_list(group_name_list=None, access_token=""):

    groups_list = []
    group_search_string = ""
    url = 'https://graph.microsoft.com/v1.0/groups'
    select = 'id'

    if group_name_list is None:
        with open(os.path.join(os.path.dirname(__file__), 'config/groups.json'), 'r') as group_file:
            parsed_json = json.load(group_file)
        group_search_string = ""
        for group_name in parsed_json[settings.ENVIRONMENT]:
            group_search_string = group_search_string + \
                '"displayName:' + group_name + '" OR '
    else:
        for group_name in group_name_list:
            group_search_string = group_search_string + \
                '"displayName:' + group_name + '" OR '

    if group_search_string != "":
        group_search_string = group_search_string.rstrip(' OR ')

    req_params = {'$select': select,
                  '$search': group_search_string, '$count': 'true'}
    printlog(req_params)

    req_header = {'Authorization': 'Bearer ' +
                  access_token, 'ConsistencyLevel': 'Eventual'}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    # printlog(response_json['value'])
    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        for groups in response_json['value']:
            try:
                printlog(groups['id'])
                groups_list.append(groups['id'])
            except Exception as e:
                printlog("EXCEPTION PARSING RESPONSE")
                printlog(e)
    return groups_list


# Add Groups to User
def add_groups_to_user(user_id, group_id_list, access_token):

    url = 'https://graph.microsoft.com/v1.0/groups/{}/members/$ref'
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}

    message = ""

    for idx in range(len(group_id_list)):
        post_url = url.format(group_id_list[idx])
        req_body = {
            "@odata.id": "https://graph.microsoft.com/v1.0/directoryObjects/{}".format(user_id)
        }
        printlog(req_body)
        for ctr in range(5):
            response = requests.post(
                post_url, data=json.dumps(req_body), headers=req_header)
            printlog("Iteration#"+str(ctr))
            printlog(int(response.status_code))
            if (int(response.status_code) == 204 or int(response.status_code) == 400):
                printlog('Assigning Group Passed')
                break
            else:
                message = 'Group Addition Failed'
                try:
                    printlog(response.json())
                except Exception as e:
                    message = 'Exception while parsing JSON'
                    printlog(message)
                sleep(2)
    return 'Groups Assigned'

# Check if User is Active


def get_user_status(user_id, access_token):
    account_enabled = False
    url = 'https://graph.microsoft.com/v1.0/users'
    req_params = {'$select': 'accountEnabled',
                  '$filter': 'id eq \''+user_id+'\''}
    req_header = {'Authorization': 'Bearer ' + access_token}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    user_id = ''
    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        printlog('User Check Result')
        printlog(response_json)
        try:
            account_enabled = response_json['value'][0]['accountEnabled']
        except Exception as e:
            printlog(e)
            account_enabled = False
    return account_enabled

# set user status


def set_user_status(user_id, user_status, access_token):
    url = 'https://graph.microsoft.com/v1.0/users/'+user_id
    req_body = {
        "accountEnabled": user_status
    }
    printlog(req_body)

    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    response = requests.patch(url, json=req_body, headers=req_header)

    printlog(response.status_code)

    if (response.status_code < 200 or response.status_code > 229):
        printlog('User Update Fail')
        try:
            printlog(response.json())
        except Exception as e:
            printlog('Exception while parsing JSON')
        return False
    else:
        printlog('User Update Pass')
        return True


def init_user_access_control(list_form_initial, user_id, access_token):
    user_group_name_list = fetch_user_groups(user_id, access_token)
    printlog(user_group_name_list)
    for records in list_form_initial:
        printlog(records)
        if records['data-group-name'] in user_group_name_list:
            records['fieldValue'] = True
            records['data-group-initial-status'] = "True"
    return list_form_initial


def groups_assign_to_user(groups_to_add, user_id, access_token):
    if len(groups_to_add):
        add_groups_to_user(user_id, get_group_id_list(
            groups_to_add, access_token), access_token)


def groups_unassign_to_user(groups_to_remove, user_id, access_token):

    if len(groups_to_remove):
        remove_groups_from_user(user_id, get_group_id_list(
            groups_to_remove, access_token), access_token)

# Fetch Groups for an user
def fetch_user_groups(user_id, access_token):
    url = 'https://graph.microsoft.com/v1.0/users/{}/memberOf?$select=id,displayName'.format(
        user_id)
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}

    response = requests.get(url, headers=req_header)       
    response_json = response.json()    
    group_name_list = []

    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        for groups in response_json['value']:
            try:
                group_name_list.append(groups['displayName'])
            except Exception as e:
                printlog("EXCEPTION PARSING RESPONSE")
                printlog(e)
    printlog("User Group Name List")
    printlog(group_name_list)
    return group_name_list


# Remove Groups From User
def remove_groups_from_user(user_id, group_id_list, access_token):
    url = 'https://graph.microsoft.com/v1.0/groups/{}/members/{}/$ref'
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}

    message = ""
    printlog("inside Remove groups")
    printlog(group_id_list)
    for idx in range(len(group_id_list)):
        del_url = url.format(group_id_list[idx], user_id)

        printlog("delurl: "+del_url)
        response = requests.delete(del_url, headers=req_header)

        printlog(int(response.status_code))
        if (int(response.status_code) == 204 or int(response.status_code) == 400):
            printlog('Group Removed')
            # break
        else:
            message = 'Group Removal Failed'
            try:
                printlog(response.json())
            except Exception as e:
                message = 'Exception while parsing JSON'
                printlog(message)

    return 'Groups Removed'

# Create a Supplier Group and return ID


def create_supplier_group(group_name, group_description, access_token):
    url = 'https://graph.microsoft.com/v1.0/groups'
    group_id = ""
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}

    req_body = {
        "description": json.dumps(group_description),
        "displayName": group_name,
        "mailEnabled": False,
        "groupTypes": [
        ],
        "mailNickname": group_name,
        "securityEnabled": True
    }
    printlog('req_body: ')
    printlog(req_body)
    response = requests.post(url, json=req_body, headers=req_header)

    response_json = response.json()

    printlog(response_json)
    if not response.ok:
        printlog('Group Creation Failed')
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        printlog('Group Creation Success')
        printlog(response_json)
        try:
            group_id = response_json['id']
        except Exception as e:
            group_id = ''
    return group_id


# Create a Supplier Group
def get_supplier_group_id(group_name, group_description, access_token):
    printlog('calling get_group_id_list: '+group_name)

    supplier_group_id_list = get_group_id_list([group_name], access_token)
    if len(supplier_group_id_list) == 0:
        supplier_group_id = create_supplier_group(
            group_name, group_description, access_token)
    else:
        supplier_group_id = supplier_group_id_list[0]
    printlog("supplier_group_id="+str(supplier_group_id))
    return supplier_group_id

# Read Extension Attribute File
def get_extension_attributes(user_id, supplier_name, supplier_id):
    extension_attributes = {}
    with open(os.path.join(os.path.dirname(__file__), 'config/extensionattributes.json'), 'r') as extension_attributes_file:
        parsed_json = json.load(extension_attributes_file)
    for environments in parsed_json['EXTENSION_ATTRIBUTES']['ENVIRONMENT']:
        if (environments['ENVIRONMENT_NAME'] == settings.ENVIRONMENT):
            for applications in environments['APPLICATION']:
                if applications['INITIAL_PROVISION'] == 'Y':
                    extension_attributes['extension_{}_ILE_Alternate_UserID_{}'.format(environments['BPG_APPLICATION_ID'], applications['ALTERNATE_USER_ID'])] = "{}|{}||{}|TRUE|{}".format(
                        applications['APPLICATION_CODE'], user_id, supplier_name, supplier_id)
                    extension_attributes[applications['EXTENSION_ATTRIBUTE_NAME']] = user_id
    return extension_attributes

#Get Group Members for a particular Group
def get_group_members(group_id, access_token):
    url = 'https://graph.microsoft.com/v1.0/groups/{}/members?$select=id,displayName'.format(
        group_id)
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}

    response = requests.get(url, headers=req_header)
    response_json = response.json()
    user_id_list = []

    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        for users in response_json['value']:
            try:
                user_id_list.append(users['id'])
            except Exception as e:
                printlog("EXCEPTION PARSING RESPONSE")
                printlog(e)

    return user_id_list


# Check if Supplier has an Admin User
def does_supplier_admin_exist(supplier_group_name, supplier_admin_group, access_token):
    result = False
    try:
        if supplier_admin_group:
            # Fetch Group Id of both the Groups
            group_id_list = get_group_id_list(group_name_list=[
                                              supplier_group_name, supplier_admin_group], access_token=access_token)
            if len(group_id_list) == 2:  # Both Supplier Group and Admin Group Exists
                # Fetch List of Users belonging to Supplier Group
                supplier_group_users = get_group_members(
                    group_id_list[0], access_token)
                # Fetch List of Users belonging to Supplier Admin Group
                supplier_admin_group_users = get_group_members(
                    group_id_list[1], access_token)
                # Loop through users in Supplier Group
                for user_id in supplier_group_users:
                    # Check if Supplier Group User exists in Supplier Admin Group
                    if user_id in supplier_admin_group_users:
                        result = True  # Sets True since the user exists in Supplier Admin Group
                        break  # BREAK OUT from the Loop
            else:  # Sets False if either of the supplier_group_name or supplier_admin_group is absent
                result = False
        else:  # Sets False if supplier_admin_group parameter is absent
            result = False
    except Exception as e:
        printlog("Exception Occured Trying to fetch Admin Group " + str(e))
        result = False
    return result

# Get Administrative Unit ID
def get_administrative_unit_id(unit_name, access_token):
    url = 'https://graph.microsoft.com/v1.0/directory/administrativeUnits?$filter=displayName eq \'{}\'&$select=id'.format(
        unit_name)
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    administrative_unit_id = ""

    response = requests.get(url, headers=req_header)
    response_json = response.json()

    if not response.ok:
        if "error" in response_json:
            printlog(response_json["error"]["code"])
            printlog(response.status_code)
    else:
        try:
            administrative_unit_id = response_json['value'][0]['id']
        except Exception as e:
            printlog("EXCEPTION PARSING RESPONSE")
            printlog(e)
    return administrative_unit_id

# Add User to Administrative Unit
def add_user_to_administrative_unit(unit_name, user_id, access_token):
    unit_id = get_administrative_unit_id(unit_name, access_token)
    printlog("Unit ID: {}".format(unit_id))

    url = 'https://graph.microsoft.com/v1.0/directory/administrativeUnits/{}/members/$ref'.format(
        unit_id)
    req_header = {'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + access_token}
    req_body = {
        "@odata.id": 'https://graph.microsoft.com/v1.0/users/{}'.format(user_id)
    }
    try:
        response = requests.post(url, json=req_body, headers=req_header)
        printlog(response.status_code)        
        if (response.status_code < 200 or response.status_code > 229):
            response_json = response.json()
            if "error" in response_json:
                printlog(response_json["error"]["code"])
                printlog(response.status_code)
    except Exception as e:
        printlog("EXCEPTION WHILE ADDING USER TO ADMIN UNIT")
        printlog(str(e))
