from django.db import models
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


def validate_duns(value):
    print(value)
    if len(str(value)) != 9:
        raise ValidationError(_("DUNS must be 9 digits in length"),
                              params={"value": value},
                              )


#Registration Form Model
class RegistrationForm(forms.Form):

    firstName = forms.CharField(max_length=50, min_length=2, label='First Name', error_messages={"required": "Please Enter First Name"}, widget=forms.TextInput(
        attrs={'class': 'form-control',  'required': True, 'aria-label': 'First Name', 'placeholder': "Enter First Name", 'tabindex':'0','oninvalid': 'this.setCustomValidity("First Name should be 2-50 characters in length")', 'oninput': 'setCustomValidity("")'}))
    lastName = forms.CharField(max_length=50, min_length=2, label='Last Name', widget=forms.TextInput(
        attrs={'class': 'form-control',  'required': True, 'aria-label': 'Last Name', 'placeholder': "Enter Last Name", 'tabindex':'0','oninvalid': 'this.setCustomValidity("Last Name should be 2-50 characters in length")', 'oninput': 'setCustomValidity("")'}))
    workEmail = forms.CharField(max_length=100, label='Work Email', widget=forms.EmailInput(
        attrs={'class': 'form-control', 'required': True, 'aria-label': 'Work Email', 'placeholder': "Enter Email (distribution emails not permitted)", 'tabindex':'0'}))
    company = forms.CharField(max_length=100, label='Legal Company Name', widget=forms.TextInput(
        attrs={'class': 'form-control', 'required': True, 'aria-label': 'Company', 'placeholder': "Enter Legal Company Name (as appears on W-9)", 'tabindex':'0'}))
    scac = forms.CharField(min_length=2, max_length=4, label='SCAC', widget=forms.TextInput(
        attrs={'class': 'form-control', 'pattern':'[A-Za-z0-9]*','required': True, 'aria-label': 'SCAC', 'placeholder': "Enter SCAC (registered with NMFTA)", 'tabindex':'0','oninvalid': 'this.setCustomValidity("SCAC should be 2-4 characters in length")', 'oninput': 'setCustomValidity("")'}))    
    '''duns = forms.CharField(validators=[validate_duns], label='DUNS', widget=forms.TextInput(
        attrs={'class': 'form-control', 'minlength':'9', 'maxlength':'9','pattern':'[0-9]*','required': True, 'aria-label': 'DUNS', 'placeholder': "Enter DUNS", 'tabindex':'0',}))'''

#User Model
class UserDetails:
    uid: int
    user_id: str
    firstName: str
    lastName: str
    workEmail: str
    company: str
    scac: str
    #duns: str
    invitationStatus: str
    supplierId: str
    responseText: str