from django.http import HttpResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import json
from time import sleep
import os
import random
import requests
from requests.auth import HTTPBasicAuth
import socket
from .uspslogger import printlog

def get_nmfta_name(scac):
    printlog("Validating NMFTA for SCAC :"+scac)
    
    NmftaHostname = settings.NMFTA_HOST_NAME
    NmftaCId = settings.NMFTA_CLIENT_ID
    NmftaCSecret = settings.NMFTA_CLIENT_SECRET
    
    print(NmftaHostname)
    print(NmftaCId)
    print(NmftaCSecret)
    
    AuthMethod = '/Authentication/auth'
    AuthUrl = 'https://{}{}'.format(NmftaHostname, AuthMethod)    
    #AuthUrl = 'https://scacapi.scaccode.com/Authentication/auth'
    printlog("Authentication URL : "+AuthUrl)
    
    SrchMethod = '/SCACSearch'
    SrchUrl = 'https://{}{}'.format(NmftaHostname, SrchMethod)  
    auth = HTTPBasicAuth(NmftaCId,NmftaCSecret)  
    
    try:
        response = requests.post(AuthUrl, auth=auth)
        printlog(response.status_code)
        print(response.text)
    
        if response.status_code == 200:
            printlog("Auth API Call Success Response")
            statusCode=response.status_code
            response_json = response.json()
            auth_token = response_json['access_token']
            
            return_dict = search_nmfta_scac(SrchUrl,scac, auth_token)
            print("get_nmfta_name return_dict")
            print(return_dict)            
            staus_code = return_dict['statusCode']                
            print(return_dict['statusCode'])
            print(return_dict['statusMessage'])
            print(return_dict['companyName'])
        else:
            printlog("Auth API Call Response Status code is not 200")
            return_dict = {"statusCode": 999,
                          "statusMessage": "Auth API Call Response Status is not success.", 
                          "companyName": ""}            
    except Exception as e:
        printlog("NMFTA Authentication call Exception :"+str(e))
        return_dict = {"statusCode": 999,
                          "statusMessage": "NMFTA Authentication call Exception :"+str(e),
                          "companyName": ""} 
    return return_dict

def search_nmfta_scac(surl,scac, auth_token):
    printlog("In search_nmfta_scac for :"+scac)
    printlog("search URL :"+surl)
    
    srch_header = {'Authorization' : f'Bearer {auth_token}'}
    srch_pload = {'SCAC' : scac,
                'sortField' : 'SCAC',
                'sortOrder' :'ASC'}     
    try:                
        sresponse = requests.post(surl, headers=srch_header, json=srch_pload)
        print(sresponse.status_code)
        print(sresponse.text) 
        if sresponse.status_code == 200:
            sresponse_json = sresponse.json()
            recCount = sresponse_json["totalCount"]
            printlog("recCount :"+str(recCount))
            
            if recCount == 0:
                company_dict = {"statusCode": 200,
                          "statusMessage": "No Record Found", 
                          "companyName": ""}     
            else:
                companyName = sresponse_json["items"][0]["companyName"]
                printlog("companyName :"+companyName)
                company_dict = {"statusCode": 200,
                          "statusMessage": "Search API Call Response Status is success.", 
                          "companyName": companyName}  
        else:
            printlog("Search SCAC API Call Response Status code is not 200")
            company_dict = {"statusCode": 999,
                          "statusMessage": "Search SCAC API Call Response Status code is not 200.", 
                          "companyName": ""}     
    except Exception as e:
        printlog("Search SCAC API Call Exception :"+str(e))
        companyName = ""     
        company_dict = {"statusCode": 999,
                          "statusMessage": "Search SCAC API Call Exception :"+str(e), 
                          "companyName": ""}    
    return company_dict
        
