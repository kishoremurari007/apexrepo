if ("undefined" == typeof jQuery) throw new Error("Missing jQuery");

/* Function to get OTP */
function getOtp() {
    var otp;
    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    const firstname = document.querySelector('[name=firstName]').value;
    const lastname = document.querySelector('[name=lastName]').value;
    const workEmail = document.querySelector('[name=workEmail]').value;
    $.post("/getotp",
        {

            "csrfmiddlewaretoken": csrftoken,
            "workEmail": workEmail,
            "displayName": firstname + " " + lastname
        })
        .done(function (data, status) {            
            if (status == "success") {
                otp = data;
                document.getElementById("resend-code").disabled = true;
                document.getElementById("error-twoFactorCode").textContent = data;
            }
            else {
                document.getElementById("error-twoFactorCode").textContent = data;
                document.getElementById("resend-code").disabled = true;
            }
        })
        .fail(function (data, status) {
            console.log(data);
            document.getElementById("error-twoFactorCode").textContent = data.responseText;
            document.getElementById("resend-code").disabled = true;
        });

}

function resendCountDown() {
    // Get refreence to span and button
    var spn = document.getElementById("span-count");
    var btn = document.getElementById("resend-code");

    var count = 15;     // Set count in seconds
    var timer = null;  // For referencing the timer

    (function countDown() {
        // Display counter and start counting down
        spn.textContent = ' in ' + count + ' seconds';

        // Run the function again every second if the count is not zero
        if (count !== 0) {
            timer = setTimeout(countDown, 1000);
            count--; // decrease the timer
        } else {
            // Enable the button
            btn.removeAttribute("disabled");
            spn.textContent = ''
        }
    }());
}
