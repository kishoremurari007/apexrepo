from django.urls import path

from . import views

urlpatterns = [    
    path('', views.init, name='bpglg'),
    path('logout', views.logout, name='bpglg-logout'),    
    path('getotp', views.generateotp, name='bpglg-getotp')
]
