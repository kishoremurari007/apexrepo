from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.conf import settings



from pathlib import Path

from django.shortcuts import render

from .uspsOtp import *
from .uspsMail import *


from .models import RegistrationForm, UserDetails
from .graph import does_user_exists, send_invitation_to_user,update_user_details,get_group_id_list,add_groups_to_user,get_supplier_group_id, get_extension_attributes, does_supplier_admin_exist, add_user_to_administrative_unit,fetch_user_groups,fetch_invitation_access_token, fetch_access_token
from .clsgraph import fetch_supplier_wrapper, create_supuser_upsert, fetch_supplier
from .nmfta_clsgraph import get_nmfta_name, search_nmfta_scac

#Import Custom Logger Module
from .uspslogger import printlog,setlogenv

# Logout Function


def logout(request):
    # Redirect to the logout endpoint of Azure Web
    printlog("Logout Initiated")
    return HttpResponseRedirect("/.auth/logout")

# Main Init Function


def init(request):
    #OPTIONAL: Set the custom Log Environment before first use. Make sure request is passed.
    setlogenv(request)
    #Call Log Function to printlog Log
    #printlog('Logger has been activated')
    #printlog(request.method)
    #optionally call logger with log level
    #printloglog('Logger has been activated in WARNING mode','WARNING')
    
    response_message = {"validation_error":"",
                        "invitation_message":""}
    # if this is a GET request present a Blank Form
    if request.method == 'GET':
        form = RegistrationForm()
        #return render(request, 'bpglgindex.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL})
        return render(request, 'bpglgindex.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL})

    # if this is a POST request we need to process the form data
    elif request.method == 'POST':
        #Fetch the Invitation Access Token
        invitation_access_token = fetch_invitation_access_token()
        #Fetch the Access Token
        access_token = fetch_access_token()
        print("IN POST ")
        printlog(request.POST)   
        form = RegistrationForm(data=request.POST)
        # check whether Form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            user_details = UserDetails()
            user_details.firstName = form.cleaned_data['firstName'].strip()
            user_details.lastName = form.cleaned_data['lastName'].strip()
            user_details.workEmail = form.cleaned_data['workEmail'].strip()
            user_details.company = form.cleaned_data['company'].strip()
            user_details.scac = form.cleaned_data['scac'].strip()
            #user_details.duns = form.cleaned_data['duns'].strip()
            user_details.responseText=""
            user_details.user_id = ""
            print(request.POST.get("hId","Submit-1"))
			#bcId = request.POST.get("hId","Submit")
            
            #if request.POST.get("hId","Submit") == "ThisisNotMe":
            if request.POST.get("rbThisisme","Submit") == "ThisisNotMe":
                printlog("Return to Form with all information displayed")
                return render(request, 'bpglgindex.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL})
            user_details=does_user_exists (user_details,access_token)                            
            if (user_details.user_id != ""):
                #If User is already assigned the BPG Group, Exit the Process.
                if ('NAT_AZURE_BPG_ILE_USR_{}'.format(settings.ENVIRONMENT) in fetch_user_groups(user_id=user_details.user_id,access_token=access_token)):
                    printlog("User already assigned to Group")
                    response_message['validation_error'] = "User Account with Email " + user_details.workEmail + ": already exists."
                    return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        
            
            #if request.POST.get("hId","Submit") == "Submit":
            if request.POST.get("rbThisisme","Submit") == "Submit" and (not 'twoFactorCode' in request.POST):
                #Check if SCAC exists in CLEAR                
                clear_scac_verify = fetch_supplier(user_details.scac,'SCAC')
                print(clear_scac_verify)
                printlog("clear_scac_verify Status code :"+str(clear_scac_verify['statusCode']))
                #printlog("clear_scac_verify j1Id :"+str(clear_scac_verify['j1Id']))
                if clear_scac_verify['statusCode']  == 200:
                    printlog("SCAC already exists in CLEAR")
                    response_message['validation_error'] = "Your Company SCAC (" + user_details.scac + ") is already registered with USPS, please contact your company administrator or ILE Onboarding at ILE_OnBoarding@usps.gov for access."
                    return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})  
                
                #NMFTA wrapper Call
                nmfta_scac_search = get_nmfta_name(user_details.scac)
                printlog(nmfta_scac_search['statusMessage'])
                if nmfta_scac_search['statusCode']  == 200:
                    printlog("nmfta_scac_search Status code :"+str(nmfta_scac_search['statusCode']))
                    if nmfta_scac_search['companyName'] != "":
                        printlog("nmfta Company Name :"+nmfta_scac_search['companyName'])
                        if nmfta_scac_search['companyName'] != user_details.company:
                            #response_message['validation_error'] = "Legal Company Name :" + user_details.company + " is not matching with NMFTA Name "+ nmfta_scac_search['companyName']
                            nmfta_company = nmfta_scac_search['companyName']
                            return render(request, 'bpglgindex.html', {'form': form, 'nmfta_flag': 'Y', 'nmfta_company': nmfta_company,'display_main_form': 'd-none', "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})
                    else:
                        response_message['validation_error'] = "SCAC is invalid. Contact NMFTA at https://nmfta.org/scac/ to obtain a SCAC"
                        return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        
                else:
                    response_message['validation_error'] = "Could not verify SCAC :" + user_details.scac + " in NMFTA. Contact System Administrator"
                    return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})  
                    
            request.session['PROCESSING_STATUS'] = 'PENDING'
                        
            if (not 'twoFactorCode' in request.POST):                     
                request.session['OTP_COUNTER'] = '0' 

            otp_validated_flag = 'N'
            otp = ""

            

            if request.session.get('OTP_COUNTER', False):
                request.session['OTP_COUNTER'] = str(int(request.session.get('OTP_COUNTER', False)) + 1)
                printlog ("Session available")             
                printlog(request.session['OTP_COUNTER'])      
            else:
                request.session['OTP_COUNTER'] = '1'
                printlog('Init Session')                                     
                printlog(request.session['OTP_COUNTER'])   
            
            if (request.POST.get('twoFactorCode', False)):
                printlog("OTP Entered by User: "+user_details.workEmail + ":" + request.POST['twoFactorCode'])
                
                
                if request.session.get('OTP', False):
                    printlog("OTP in SESSION")
                    printlog(request.session['OTP'])
                    validate_otp_result = validate_otp_wrapper(int(request.session['OTP']),int(request.POST['twoFactorCode']),int(request.session['OTP_COUNTER']),int(request.session['OTP_EXPIRES_AT']))

                    if (validate_otp_result==""):
                        otp_validated_flag = 'Y'
                        supplier_group_name=""
                        supplier_group_description = ""
                        #Uncomment in real USPS
                        supplier_result = fetch_supplier_wrapper(user_details)
                       
                        #supplier_result = {} #Only for USPS Test
                        #supplier_result['clsj1Id'] = '999' #Only for USPS Test
                        #supplier_result['userCreated'] = 'Y' #Only for USPS Test
                        

                        if (supplier_result['clsj1Id'] == ""):

                            del request.session['OTP_COUNTER']
                            del request.session['OTP']
                            del request.session['OTP_EXPIRES_AT']
                            response_message['validation_error']=supplier_result['statusMessage']
                            return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        
                        else:                        
                            supplier_group_name = "NAT_AZURE_SUPPLIER_{}_ILE_{}".format(supplier_result['clsj1Id'],settings.ENVIRONMENT)                            
                            supplier_group_description = {
                                    "supplierName": user_details.company,
                                    "supplierDomainName": user_details.workEmail.split('@')[1],
                                    "supplierID": supplier_result['clsj1Id'],
                                    "APEXID": "",
                                    "SCAC": user_details.scac,
                                    #"DUNS": user_details.duns
                                }
                            printlog("supplier_group_name "+supplier_group_name)
                            printlog(supplier_group_description)  

                            #If Supplier Admin Exists, respond with an Error Message
                            if supplier_result['userCreated'] == "N" and does_supplier_admin_exist (supplier_group_name=supplier_group_name,supplier_admin_group=settings.AZURE_CLS_ADMIN_GROUP,access_token=access_token):
                                del request.session['OTP_COUNTER']
                                del request.session['OTP']
                                del request.session['OTP_EXPIRES_AT']
                                response_message['validation_error']='Your company is already registered with USPS, please contact your company\'s administrator for access.'
                                return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        
                            else:
                                if supplier_result['userCreated'] == "N":
                                    #If User was not created by CLS, create User
                                    try:
                                        csuapi_response = create_supuser_upsert(
                                            supplier_result['clserpNum'], supplier_result['clsj1Id'], True, user_details.firstName, user_details.lastName, user_details.workEmail)
                                        print('Supplier User Upsert API Response')
                                        print(csuapi_response)
                                        #statusCode = csuapi_response['statusCode']
                                        if (csuapi_response['statusCode'] == 204):
                                            # create_supuser_upsert success
                                            print(csuapi_response['statusDesc'])
                                            #Set UserCreated as Y
                                            supplier_result['userCreated'] = "Y"
                                        elif (csuapi_response['statusCode'] == 400):
                                            # create_supuser_upsert validation error
                                            print(csuapi_response['statusDesc'])
                                            print(csuapi_response['errorDetails'])
                                        else:
                                            # Other exception
                                            print(csuapi_response['statusDesc'])                                        
                                    except Exception as e:
                                        print("Exception while calling CLS API Supplier User Upsert - "+str(e))
                                    #If User is not created, STOP
                                    if (supplier_result['userCreated'] == "N"):
                                            del request.session['OTP_COUNTER']
                                            del request.session['OTP']
                                            del request.session['OTP_EXPIRES_AT']
                                            response_message['validation_error']='Error encountered while creating user. Please contact USPS Helpdesk.'
                                            return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        
                                    
                            user_details=does_user_exists (user_details,access_token)                            
                            if (user_details.user_id == ""):
                                user_details=send_invitation_to_user (user_details,invitation_access_token)
                                response_message['invitation_message'] = "An invitation was sent to: " + user_details.workEmail + ".\nPlease check your email at that address to accept the invitation and finalize your registration."
                            else:
                                #If User is already assigned the BPG Group, Exit the Process.
                                #if ('NAT_AZURE_BPG_ILE_USR_{}'.format(settings.ENVIRONMENT) in fetch_user_groups(user_id=user_details.user_id,access_token=access_token)):
                                #    printlog("User already assigned to Group")
                                #   del request.session['OTP_COUNTER']
                                #    del request.session['OTP']
                                #    del request.session['OTP_EXPIRES_AT']
                                #    response_message['validation_error'] = "User Account with Email " + user_details.workEmail + ": already exists."
                                #    return render(request, 'bpglgindex.html', {'form': form, "response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                        

                                response_message['invitation_message'] = "Logistics Gateway Access has been granted to " + user_details.workEmail + ".\nYour account is ready for use."
                            extension_attributes=get_extension_attributes(user_details.user_id, user_details.company,supplier_result['clsj1Id'])
                            printlog(extension_attributes)
                            if user_details.user_id != "":
                                add_user_to_administrative_unit(unit_name=settings.ADMINISTRATIVE_UNIT_NAME, user_id=user_details.user_id, access_token=invitation_access_token)
                                user_details_update_response = update_user_details(user_details.user_id,user_details.firstName,user_details.lastName,user_details.company,"",extension_attributes,access_token)
                                printlog(user_details_update_response)
                                groups_list = get_group_id_list(group_name_list=None,access_token=access_token)
                                groups_list.append(get_supplier_group_id (supplier_group_name, supplier_group_description,access_token))
                                group_assignment_result=add_groups_to_user(user_details.user_id,groups_list,access_token)                 
                            del request.session['OTP_COUNTER']
                            del request.session['OTP']
                            del request.session['OTP_EXPIRES_AT']                        
                            request.session['PROCESSING_STATUS'] = 'COMPLETE'
                            return render(request, 'bpglgindex.html', {  'display_main_form': 'd-none', 'otp_flag': 'N',"response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                    
                    else:
                        response_message = {"error_twoFactorCode":validate_otp_result}
            else:
                #Generate OTP  
                request = generate_otp_wrapper(request)
                #Send Email
                email_to_arr=[{"address": user_details.workEmail,"displayName": user_details.firstName + " " + user_details.lastName}]
                email_subject = "Enter One-Time Passcode for USPS Logistics Gateway Registration"
                email_plain_text = "Please use following One Time Code for registering: " + request.session['OTP']
                email_html_text = get_otp_html(user_details.firstName + " " + user_details.lastName,request.session['OTP'])#"<html><head><title>OTP</title></head><body><h2>Please use following One Time Code for registering: " + request.session['OTP'] + "</h2><h3>Note: The Code is valid for " + str(int(OTP_EXPIRATION_SECONDS/60)) + " minutes</h3></body></html>"
                send_email_wrapper(email_from="", email_to_arr=email_to_arr, email_subject=email_subject, email_plain_text=email_plain_text, email_html_text=email_html_text)                
            return render(request, 'bpglgindex.html', {'form': form, 'otp_flag': 'Y',  'display_main_form': 'd-none', 'otp_validated_flag': otp_validated_flag,"response_message":response_message, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})            
        else: #If form is not Valid
            return render(request, 'bpglgindex.html', {'form': form, "BPG_LOGIN_URL": settings.BPG_LOGIN_URL})                         
#@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def generateotp(request):
    printlog(request.method)
    if request.method == 'POST':
        printlog(request.session.get('PROCESSING_STATUS','P'))
        if (request.session.get('PROCESSING_STATUS','PENDING') == 'COMPLETE'):              
            return HttpResponse('Invitation has already been sent',content_type="text/plain",status=200)
        #Generate OTP  
        request = generate_otp_wrapper(request)
        #Send Email     
        email_to_arr=[{"address": request.POST['workEmail'],"displayName": request.POST['displayName']}]
        email_subject = "Enter One-Time Passcode for USPS Logistics Gateway Registration"
        email_plain_text = "Please use following One Time Code for registering: " + request.session['OTP']
        email_html_text = get_otp_html(request.POST['displayName'],request.session['OTP'])#"<html><head><title>OTP</title></head><body><h2>Please use following One Time Code for registering: " + request.session['OTP'] + "</h2><h3>Note: The Code is valid for " + str(int(OTP_EXPIRATION_SECONDS/60)) + " minutes</h3></body></html>"
        send_email_wrapper(email_from="", email_to_arr=email_to_arr, email_subject=email_subject, email_plain_text=email_plain_text, email_html_text=email_html_text)            
        return HttpResponse('One Time Code has been resent',content_type="text/plain",status=200)
