from django.db import models
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from .graph import read_extension_attributes_file


def validate_duns(value):
    if len(str(value)) != 9:
        raise ValidationError(_("DUNS must be 9 digits in length"),
                              params={"value": value},
                              )
# Create your models here.

# creating a form


class RegistrationForm(forms.Form):

    firstName = forms.CharField(max_length=50, min_length=2, label='First Name', error_messages={"required": "Please Enter First Name"}, widget=forms.TextInput(
        attrs={'class': 'form-control',  'required': True, 'aria-label': 'First Name', 'placeholder': "Enter First Name", 'tabindex': '0', 'oninvalid': 'this.setCustomValidity("First Name should be 2-50 characters in length")', 'oninput': 'setCustomValidity("")'}))
    lastName = forms.CharField(max_length=50, min_length=2, label='Last Name', widget=forms.TextInput(
        attrs={'class': 'form-control',  'required': True, 'aria-label': 'Last Name', 'placeholder': "Enter Last Name", 'tabindex': '0', 'oninvalid': 'this.setCustomValidity("Last Name should be 2-50 characters in length")', 'oninput': 'setCustomValidity("")'}))
    workEmail = forms.CharField(max_length=100, label='Work Email', widget=forms.EmailInput(
        attrs={'class': 'form-control', 'required': True, 'aria-label': 'Work Email', 'placeholder': "Enter Work Email", 'tabindex': '0'}))
    company = forms.CharField(max_length=100, label='Company', widget=forms.TextInput(
        attrs={'class': 'form-control', 'required': True, 'aria-label': 'Company', 'placeholder': "Enter Company", 'tabindex': '0'}))
    scac = forms.CharField(min_length=2, max_length=4, label='SCAC', widget=forms.TextInput(
        attrs={'class': 'form-control', 'pattern': '[A-Za-z0-9]*', 'required': True, 'aria-label': 'SCAC', 'placeholder': "Enter SCAC", 'tabindex': '0', 'oninvalid': 'this.setCustomValidity("SCAC should be 2-4 characters in length")', 'oninput': 'setCustomValidity("")'}))
    '''duns = forms.CharField(validators=[validate_duns], label='DUNS', widget=forms.TextInput(
        attrs={'class': 'form-control', 'minlength': '9', 'maxlength': '9', 'pattern': '[0-9]*', 'required': True, 'aria-label': 'DUNS', 'placeholder': "Enter DUNS", 'tabindex': '0', }))'''
    apexId = forms.CharField(max_length=20, min_length=1, label='Apex ID', required=False, widget=forms.TextInput(
        attrs={'class': '',  'required': False, 'aria-label': 'Apex ID', 'placeholder': "Enter Apex ID", 'tabindex': '0'}))


class UserMgmtSearchForm(forms.Form):

    lastName = forms.CharField(max_length=50, min_length=2, required=False, label='Last Name', widget=forms.TextInput(
        attrs={'class': 'form-control search-form', 'aria-label': 'Last Name', 'placeholder': "Search by Last Name"}))
    firstName = forms.CharField(max_length=50, min_length=2, required=False, label='First Name', widget=forms.TextInput(
        attrs={'class': 'form-control search-form',  'aria-label': 'First Name', 'placeholder': "Search by First Name"}))
    workEmail = forms.CharField(max_length=100, required=False, label='Email', widget=forms.TextInput(
        attrs={'class': 'form-control search-form', 'aria-label': 'Email', 'placeholder': "Search by Email"}))
    company = forms.CharField(max_length=100, required=False, label='Company', widget=forms.TextInput(
        attrs={'class': 'form-control search-form', 'aria-label': 'Company', 'placeholder': "Search by Company"}))
    scac = forms.CharField(min_length=2, max_length=4, required=False, label='SCAC', widget=forms.TextInput(
        attrs={'class': 'form-control search-form', 'aria-label': 'SCAC', 'placeholder': "Search by SCAC", 'oninvalid': 'this.setCustomValidity("SCAC should be 2-4 characters in length")', 'oninput': 'setCustomValidity("")'}))
    '''duns = forms.CharField(required=False, max_length=9, label='DUNS', widget=forms.TextInput(
        attrs={'class': 'form-control search-form', 'pattern': '[0-9]*', 'aria-label': 'DUNS', 'placeholder': "Search by DUNS"}))'''

    pendingInvitationFlag = forms.BooleanField(
        widget=forms.CheckboxInput(
            attrs={'class': 'form-check-input', 'aria-label': 'Pending Invitation'}),
        required=False, label='Pending Invitation'
    )


YES_NO_CHOICES = [
    ('YES', 'YES'),
    ('NO', 'NO')
]


class UserAccessControlForm(forms.Form):

    activeUserFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Active User'}),
        required=False, label='Active User'
    )

    resendInvitationFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Resend Invitation'}),
        required=False, label='Resend Invitation'
    )

    adminFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Admin', 'data-group-application-code': "BPG_ADMIN", 'data-group-initial-status': "False"}),
        required=False, label='Admin'
    )

    '''logisticsGatewayFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Logistics  Gateway', 'data-group-application-code': "BPG", 'data-group-initial-status': "False", 'data-group-name': 'NAT_AZURE_BPG_ILE'}),
        required=False, label='Logistics Gateway'
    )'''

    freightAuctionFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Manage My Trips', 'data-group-application-code': "FA", 'data-group-initial-status': "False"}),
        required=False, label='Manage My Trips'
    )

    stafFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Surface Transportation Automated Forms', 'data-group-application-code': "STAF", 'data-group-initial-status': "False"}),
        required=False, label='Surface Transportation Automated Forms'
    )

    clearSupplierFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'CLEAR: Supplier/Contract Management (SM/C+)', 'data-group-application-code': "CLEAR_SUPPLIER", 'data-group-initial-status': "False"}),
        required=False, label='CLEAR: Supplier/Contract Management (SM/C+)'
    )

    clearRateFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'CLEAR: Transportation Rate Management (TRM)', 'data-group-application-code': "CLEAR_TRM", 'data-group-initial-status': "False"}),
        required=False, label='CLEAR: Transportation Rate Management (TRM)'
    )

    clearASOFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'CLEAR: ASO Homepage (Solicitations)', 'data-group-application-code': "CLEAR_ASO", 'data-group-initial-status': "False"}),
        required=False, label='CLEAR: ASO Homepage (Solicitations)'
    )

    '''ileReportingFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'View My  Payment Reports', 'data-group-application-code': "ILERPT", 'data-group-initial-status': "False"}),
        required=False, label='View My Payment Reports'
    )'''


    '''fourKitesFlag = forms.BooleanField(
        widget=forms.RadioSelect(choices=YES_NO_CHOICES,
                                 attrs={'class': 'form-check-input', 'aria-label': 'Enable GPS Tracking', 'data-group-application-code': 'GPS', 'data-group-initial-status': "False"}),
        required=False, label='Enable GPS Tracking'
    )'''

class UserRegisterAppForm(UserAccessControlForm):
    apexId = forms.CharField(max_length=20, min_length=1, label='Apex ID', required=False, widget=forms.TextInput(
        attrs={'class': '',  'required': False, 'aria-label': 'Apex ID', 'placeholder': "Enter Apex ID", 'tabindex': '0'}))    
    def __init__(self, *args, **kwargs):
        super(UserRegisterAppForm, self).__init__(*args, **kwargs)
        self.fields.pop('activeUserFlag')
        self.fields.pop('resendInvitationFlag')        
        #self.fields.pop('logisticsGatewayFlag')
        

class UserRegisterAppSuppForm(UserAccessControlForm):
    def __init__(self, *args, **kwargs):
        super(UserRegisterAppSuppForm, self).__init__(*args, **kwargs)
        self.fields.pop('activeUserFlag')
        self.fields.pop('resendInvitationFlag')        
        #self.fields.pop('logisticsGatewayFlag')

# User Model
class UserDetails:
    uid: int
    user_id: str
    firstName: str
    lastName: str
    workEmail: str
    company: str
    scac: str
    #duns: str
    invitationStatus: str
    supplierId: str
    apexId: str
    responseText: str
