//////////////////////////
// LOGISTICS GATEWAY JS //
//////////////////////////

$(document).ready(function() {
  
// GENERAL FUNCTIONS

	// Prevent <a> tags with 'href="#"' from jumping to the top of the page
	$('body').on('click touch', '.container-fluid a[href="#"], .modal a[href="#"], .popover a[href="#"]', function(e) {
		e.preventDefault();
	});
	
	// Bring focus to beginning text of modal when opened.
	$("#review-order-modal").on('shown.bs.modal', function(){
        $('.modal-title').focus();
    });
	
	// Bring the focus to the Contact Information section after the user selects "Edit".
	$('.btn-link:first').on('click touch', function(e) {
		$('#review-order-modal').modal('hide'); 
		$('#contact-information').focus();
	});
	$('.btn-link:last').on('click touch', function(e) {
		$('#review-order-modal').modal('hide'); 
		$('#shipping-address').focus();
	});
	
	
	
// MAIN HEADER / NAVIGATION

	// Display or hide the "Logout" link and the tab navigation based on the current page URL.
	switch(window.location.pathname) {
		case "/test/logistics-gateway/home.htm":
		$('.logout-link').show();
		break;
        case "/test/logistics-gateway/manage-supplier-users.htm":
		case "/test/logistics-gateway/manage-users.htm":
        case "/test/logistics-gateway/manage-users-read-only.htm":
        $('.logout-link').show();
		$('.lg-main-navigation').show();
        break;
        default:
        break;
	};	
	
	
	
// START LOGIN

	// Display the register form in mobile view after clicking the "Register Now" button
	$('.btn-register').click(function() {
		$('.lg-login-container').addClass('open-form');
    });
	
	
	
// START POPOVER

	// Display the SCAC popover
	$('#scac-id').popover({
		html : true, 
		placement: 'auto',
		content: function() {
			return $('.scac-popover').html();
		} 
	});
	
	// Display the DUNS popover
	$('#duns-id').popover({
		html : true, 
		placement: 'auto',
		content: function() {
			return $('.duns-popover').html();
		} 
	});	

	// Close the popover upon clicking on the 'X'.
	$(document).on('click', '.popover .close' , function(){
			$(this).parents('.popover').popover('hide');
	});
	
	// Prevent having two or more popover (tooltip) open.
	$('.info-popover').on('click', function (e) {
		$('.info-popover').not(this).popover('hide');
	});
	$('html').on('show.bs.popover click', function(e) {
		if( e.namespace !== 'bs.popover' && !$(e.target).parents().hasClass('popover') && !$(e.target).hasClass('info-popover') ){
			$('.info-popover').popover('hide');
		}
	});	
	
	// Resize functionality between Desktop, Tablet, and Mobile view.
	var resizeTimer;
	$(window).on('resize', function(e) {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function() {
			// Run code here, resizing has "stopped"
				$('.info-popover').popover('hide');
				$this.focus();
		}, 250);
	});	
	
	
	
// START Manage Supplier Users

	// Set variable for the Logistics Manage Existing Users Table
	var manageUserTable = $('.logistics-manage-user-table tbody');

	// Sort Alphabetically
	function sortAlphabetical(index, toggleSort,$tbody ){
		(toggleSort)?
		$tbody.find('tr').sort(function(a,b){
			var tda = $(a).find('td').eq(index).text().toUpperCase();
			var tdb = $(b).find('td').eq(index).text().toUpperCase();
			return tda.localeCompare(tdb);
		}).appendTo($tbody) :
		$tbody.find('tr').sort(function(a,b){
			var tda = $(a).find('td').eq(index).text().toUpperCase();
			var tdb = $(b).find('td').eq(index).text().toUpperCase();
			return tdb.localeCompare(tda);
			}).appendTo($tbody);
	};

	// Sort Logicstics Manage Existing Users Table by Lastname.
	var lastnameToggle = false;
	$('.lastname-sort').on('click touch', function(){
		lastnameToggle = (lastnameToggle==false)? true: false;
		sortAlphabetical(0,lastnameToggle, manageUserTable );
		return false;
	});

	// Sort Logistics Manage Existing Users Table by Firstname.
	var firstnameToggle = false;
	$('.firstname-sort').on('click touch', function(){
		firstnameToggle = (firstnameToggle==false)? true: false;
		sortAlphabetical(1,firstnameToggle, manageUserTable );
		return false;
	});


	
// START Manage Users Table
	
	// Set Variable for the Logistics Users Table in User Management Page
	var logisticsUsersTable = $('.logistics-users-table tbody');

	// Sort Alphabetically
	function sortAlphabetical(index, toggleSort,$tbody ){
		(toggleSort)?
		$tbody.find('tr').sort(function(a,b){
			var tda = $(a).find('td').eq(index).text().toUpperCase();
			var tdb = $(b).find('td').eq(index).text().toUpperCase();
			return tda.localeCompare(tdb);
		}).appendTo($tbody) :
		$tbody.find('tr').sort(function(a,b){
			var tda = $(a).find('td').eq(index).text().toUpperCase();
			var tdb = $(b).find('td').eq(index).text().toUpperCase();
			return tdb.localeCompare(tda);
			}).appendTo($tbody);
	};

	//Sort Numbers	
	function sortNumbers(index, toggleSort,$tbody ){
		(toggleSort)?
		$tbody.find('tr').sort(function(a,b){ 
			var tda =$.trim($(a).find('td').eq(index).text());
			var tdb = $(b).find('td').eq(index).text(); 
			return tda - tdb;
		}).appendTo($tbody) :
		$tbody.find('tr').sort(function(a,b){ 
			var tda = $(a).find('td').eq(index).text();
			var tdb = $(b).find('td').eq(index).text(); 
			return tdb - tda;
		}).appendTo($tbody);
	} 

	// Sort Logistics Users Table by Lastname.
	var usersLastnameToggle = false;
	$('.users-lastname-sort').on('click touch', function(){
		usersLastnameToggle = (usersLastnameToggle==false)? true: false;
		sortAlphabetical(0,usersLastnameToggle, logisticsUsersTable );
		return false;
	});

	// Sort Logistics Users Table by Firstname.
	var usersFirstnameToggle = false;
	$('.users-firstname-sort').on('click touch', function(){
		usersFirstnameToggle = (usersFirstnameToggle==false)? true: false;
		sortAlphabetical(1,usersFirstnameToggle, logisticsUsersTable );
		return false;
	});

	// Sort Logistics Users Table by Company name.
	var usersCompanyToggle = false;
	$('.users-company-sort').on('click touch', function(){
		usersCompanyToggle = (usersCompanyToggle==false)? true: false;
		sortAlphabetical(3,usersCompanyToggle, logisticsUsersTable );
		return false;
	});

	// Sort Logistics Users Table by SCAC name.
	var usersScacToggle = false;
	$('.users-scac-sort').on('click touch', function(){
		usersScacToggle = (usersScacToggle==false)? true: false;
		sortAlphabetical(4,usersScacToggle, logisticsUsersTable );
		return false;
	});

	// Sort Logistics Users Table by DUNS number.
	var usersDunsToggle = false;
	$('.users-duns-sort').on('click touch', function(){
		usersDunsToggle = (usersDunsToggle==false)? true: false;
		sortNumbers(5,usersDunsToggle, logisticsUsersTable );
		return false;
	});
	
	

// 508 COMPLIANCE
    
	// Focus on Error
	$('.test-btn').on('click touch', function(e) {
		$("input.error-input:first").focus();
	});

	// Bring the tabbing focus to the elements inside the MODAL once opened and keep it there until closed.
	$('a[data-bs-toggle="modal"]').on('click touch', function (e) {
        loopingModalFocus($(this).attr('data-bs-target'),$(this));
    });
    function loopingModalFocus(modalId, trigaredLoct) {
		// add all the elements inside modal which you want to make focusable
		const  focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
		const modal = document.querySelector(modalId);
		const firstFocusableElement =(modal!= null)? modal.querySelectorAll(focusableElements)[0]:[]; 
		const focusableContent =(modal!= null)? modal.querySelectorAll(focusableElements):[];
		const lastFocusableElement = focusableContent[focusableContent.length - 1]; 
		$(document).on('keydown', function(e) {
			var isTabPressed = e.key === 'Tab' || e.keyCode === 9;
			if (!isTabPressed) {
				return;
			}
			if (e.shiftKey) { 
				if (document.activeElement === firstFocusableElement) {
					lastFocusableElement.focus(); 
					e.preventDefault();
				}
			} else { 
				if (document.activeElement === lastFocusableElement) {
					firstFocusableElement.focus(); 
					e.preventDefault();
				}
			}
		});
		$('.modal').on('shown.bs.modal', function (e) {
			firstFocusableElement.focus();
		});
		$('.modal').on('hidden.bs.modal', function(e) {
			trigaredLoct.focus();
		});
	}
  	$('input[data-bs-toggle="modal"]').keyup(function (e) {
    	if (e.keyCode === 13) {
        	var id = $(this).attr('data-bs-target');
        	$(id).modal('show');
        	loopingModalFocus($(this).attr('data-bs-target'),$(this));
        }
    });  
	$('input[data-bs-toggle="modal"]').on('click touch', function (e) {
		loopingModalFocus($(this).attr('data-bs-target'),$(this));
	}); 
	
	// 508 compliance Bring the tabbing focus to the elements inside the POPOVER once opened and keep it there until closed. 
	var $this;
	$('.info-popover').on('click touch',function() {
        $this = $(this);
	});
	$('.info-popover').focusout(function() {
        $('.popover.show a.close').focus();
	});
	$(document).on('keydown', '.popover.show .popover-wrapper', function(e) {
		const  focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
		const popover =document.getElementById($('.popover.show').attr('id'));
		const firstFocusableElement = popover.querySelectorAll(focusableElements)[0]; 
		const focusableContent =popover.querySelectorAll(focusableElements);
		const lastFocusableElement = focusableContent[focusableContent.length - 1]; 
		var isTabPressed = e.key === 'Tab' || e.keyCode === 9;
		if (!isTabPressed) {
			return;
		}
		if (e.shiftKey) { 
			if (document.activeElement === firstFocusableElement) {
				lastFocusableElement.focus(); 
				e.preventDefault();
			}
		} else { 
			if (document.activeElement === lastFocusableElement) {
				firstFocusableElement.focus(); 
				e.preventDefault();
			}
		}
	});
	$(document).on('click touch','.popover.show a.close', function(){
		$this.focus();
	});	
	
});	