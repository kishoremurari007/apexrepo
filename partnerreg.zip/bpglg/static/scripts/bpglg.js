if ("undefined" == typeof jQuery) throw new Error("Missing jQuery");

function logout() {
    console.log("Redirecting to AAD Logout")
    location.href = 'logout';
}


function resendInvitation(firstname, lastname, workEmail, btnId) {
    $('#' + btnId).attr('disabled', true);
    $('#' + btnId).html('Resending');

    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    $.post("/resendinvitation",
        {

            "csrfmiddlewaretoken": csrftoken,
            "workEmail": workEmail,
            "firstName": firstname,
            "lastName": lastname
        })
        .done(function (data, status) {
            if (status == "success") {
                $("#resendInvitationModalBody").html(data);
                $('#resendInvitationModal').modal('show');
                $('#' + btnId).attr('disabled', false);
                $('#' + btnId).html('Resend Invitation');
            }
            else {
                $("#resendInvitationModalBody").html(data);
                $('#resendInvitationModal').modal('show');
                $('#' + btnId).attr('disabled', false);
                $('#' + btnId).html('Resend Invitation');
            }
        })
        .fail(function (data, status) {
            console.log(data);
            $('#' + btnId).attr('disabled', false);
            $('#' + btnId).html('Resend Invitation');
        });

}

function displayUserAccessControl(user_id, firstname, lastname, workEmail, company, invitationStatus) {
    $('#userAccessControlModalSubmit').removeClass('hidden');
    $('#userAccessControlModalClose').addClass('hidden');
    $('#pleaseWaitDialog').modal('show');

    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    $.get("/getuseraccesscontrolform",    
        {

            "csrfmiddlewaretoken": csrftoken,
            "user_id": user_id,
            "workEmail": workEmail,
            "firstName": firstname,
            "lastName": lastname
        })
        .done(function (data, status) {
            if (status == "success") {
                $("#permission-user-name").html('User: ' + firstname + ' ' + lastname);
                $("#user-permissions-modal-body").html(data);
                if (invitationStatus != "PendingAcceptance") {
                    $("[name='resendInvitationFlag']").attr("disabled", true);
                }
                $('<input>').attr('type', 'hidden').attr('name', 'modal_user_id').attr('value', user_id).attr('id', 'modal_user_id').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_first_name').attr('value', firstname).attr('id', 'modal_first_name').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_last_name').attr('value', lastname).attr('id', 'modal_last_name').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_work_email').attr('value', workEmail).attr('id', 'modal_work_email').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_company').attr('value', company).attr('id', 'modal_company').appendTo('#user-permissions-modal-body');
                $('#pleaseWaitDialog').modal('hide');
                //$('#userAccessControlModal').modal('show');
                $('#user-permissions-modal').modal('show');
            }
            else {
                $("#user-permissions-modal-body").html(data);
                $('#pleaseWaitDialog').modal('hide');
                //$('#userAccessControlModal').modal('show');
                $('#user-permissions-modal').modal('show');
            }
        })
        .fail(function (data, status) {
            console.log(data);
        });

}


function saveUserAccessControl(user_id, first_name, last_name, work_email, company, apex_id) {

    $('#pleaseWaitDialog').modal('show');

    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;    
    
    var formdata = new FormData();
    $('#userAccessControlForm').find(':radio:checked').each(function () {
        formdata.append(this.name, ($(this).val()=="YES")?true:false);
        console.log(this.name);
        console.log($(this).val());
    });
    formdata.append('csrfmiddlewaretoken', csrftoken);
    formdata.append('user_id', user_id);
    formdata.append('first_name', first_name);
    formdata.append('last_name', last_name);
    formdata.append('work_email', work_email);
    formdata.append('company', company);
    formdata.append('apexId', apex_id);
    $('#user-permissions-modal').modal('hide');
    $.ajax({
        url: 'setuseraccesscontrolform',
        data: formdata,
        type: 'POST',
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
           /* $("#confirmation-dialog-message").html("<p>User attributes have been updated. Please requery to see changes.</p>");
            $('#pleaseWaitDialog').modal('hide');          
            $('#user-permissions-modal').modal('hide');
            $('#confirmation-dialog-modal').modal('show');*/
            $("#confirmation-dialog-message").html("<p>"+data+"</p>");
            $('#pleaseWaitDialog').modal('hide');          
            $('#user-permissions-modal').modal('hide');
            $('#confirmation-dialog-modal').modal('show');
        },
        error: function (err) {
            console.log(err);
            $("#confirmation-dialog-message").html("<p>An Unexpected Error occured while granting access. Please Retry.</p>");
            $('#pleaseWaitDialog').modal('hide');                        
            $('#confirmation-dialog-modal').modal('show');

        }
    });

}

function registerUserAppList(firstname, lastname, workEmail, company, scac,suppadmin/*, duns*/) {
    console.log("INSIDE FUNC");
	if (typeof company == 'undefined' || company == null)
		company = "null";
	if (typeof scac == 'undefined' || scac == null)
		scac = "null";
    $('#userAccessControlModalSubmit').removeClass('hidden');
    $('#userAccessControlModalClose').addClass('hidden');
    //$('#pleaseWaitDialog').modal('show');

    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
 
    $.get("/getuserregisterappform",
        {

            "csrfmiddlewaretoken": csrftoken,
			"suppadmin": suppadmin
        })
        .done(function (data, status) {
            if (status == "success") {
                $("#permission-user-name").html('User: ' + firstname + ' ' + lastname);
                $("#user-permissions-modal-body").html(data);
                $("#save-user-permission").html('Create User');
                $("#permission-label").html('Add Permissions');
                
                $('#save-user-permission').removeAttr('onclick');

                $('#save-user-permission').on('click', function(){createUser(firstname, lastname, workEmail, company, scac/*, duns*/);});   
               
                                
                $('<input>').attr('type', 'hidden').attr('name', 'modal_first_name').attr('value', firstname).attr('id', 'modal_first_name').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_last_name').attr('value', lastname).attr('id', 'modal_last_name').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_work_email').attr('value', workEmail).attr('id', 'modal_work_email').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_company').attr('value', company).attr('id', 'modal_company').appendTo('#user-permissions-modal-body');
                $('<input>').attr('type', 'hidden').attr('name', 'modal_scac').attr('value', scac).attr('id', 'modal_scac').appendTo('#user-permissions-modal-body');
                //$('<input>').attr('type', 'hidden').attr('name', 'modal_duns').attr('value', duns).attr('id', 'modal_duns').appendTo('#user-permissions-modal-body');                
                $('#user-permissions-modal').modal('show');
            }
            else {
                $("#user-permissions-modal-body").html(data);
                $('#pleaseWaitDialog').modal('hide');
                //$('#userAccessControlModal').modal('show');
                $('#user-permissions-modal').modal('show');
            }
        })
        .fail(function (data, status) {
            console.log(data);
        });

}

function createUser(first_name, last_name, work_email, company, scac/*, duns*/) {

    //console.log("Inside Create User")
    $("#pleaseWaitDialog .modal-title").html('Your Account is being set up. This may take 1-2 minutes.<br>Please do not navigate away or close this page.');
    $('#pleaseWaitDialog').modal('show');

    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;    
    
    var formdata = new FormData();
    $('#userAccessControlForm').find(':radio:checked').each(function () {
        formdata.append(this.name, ($(this).val()=="YES")?true:false);
        console.log(this.name);
        console.log($(this).val());
    });
    
    formdata.append('csrfmiddlewaretoken', csrftoken);    
    formdata.append('firstName', first_name);
    formdata.append('lastName', last_name);
    formdata.append('workEmail', work_email);
    formdata.append('company', company);
    formdata.append('scac', scac);
    //formdata.append('duns', duns);
    var apex_id = $('input[name="apexId"]').val();
    formdata.append('apexId', apex_id);
    formdata.append('registerUserToggle', "YES");
    $('#user-permissions-modal').modal('hide');
    $.ajax({
        url: 'setuserregisterappform',
        data: formdata,
        type: 'POST',
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
            console.log(data)
            $("#confirmation-dialog-message").html("<p>"+data+"</p>");
            $('#pleaseWaitDialog').modal('hide');          
            $('#user-permissions-modal').modal('hide');
            $('#confirmation-dialog-modal').modal('show');
        },
        error: function (err) {
            console.log(err);
            $("#confirmation-dialog-message").html("<p>An Unexpected Error occured while granting access. Please Retry.</p>");
            $('#pleaseWaitDialog').modal('hide');                        
            $('#confirmation-dialog-modal').modal('show');

        }
    });

}


function restorePrompts(){
    $('#btnRegisterUsersubmit').attr('disabled', false);
	$('#btnRegisterUsersubmit').html('Register New User');
}
