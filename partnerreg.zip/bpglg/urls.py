from django.urls import path

from . import views

urlpatterns = [    
    path('', views.usermgmt, name='bpglg-usermgmt'),
    path('logout', views.logout, name='bpglg-logout'), 
    path('resendinvitation', views.resendinvite, name='bpglg-resendinvite'),
    path('getuseraccesscontrolform', views.get_user_access_control_form, name='bpglg-user-get-user-access-control-form'),
    path('setuseraccesscontrolform', views.get_user_access_control_form, name='bpglg-user-set-user-access-control-form'),
    path('getuserregisterappform', views.get_user_register_app_form, name='bpglg-user-get_user_register_app_form'),
    path('setuserregisterappform', views.get_user_register_app_form, name='bpglg-user-set_user_register_app_form'),
    
]
