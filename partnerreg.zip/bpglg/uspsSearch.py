from django.conf import settings
from .models import UserDetails
from .graph import get_group_members,get_group_id_list,fetch_user_groups,fetch_user_supplier_group,get_logged_in_user,get_user_id
from .clsgraph import fetch_supplier
import requests
import json
from .uspslogger import printlog
import os


def search_users(UserDetails, access_token,request,supplier_context_flag):
    users_list = []
    error_msg = ""  
    try:           
        users_list,error_msg = list_users (email = UserDetails.workEmail,firstName=UserDetails.firstName,lastName=UserDetails.lastName,company=UserDetails.company, scac=UserDetails.scac, invitationStatus=UserDetails.invitationStatus,access_token=access_token,request=request,supplier_context_flag=supplier_context_flag)  
        printlog('@@@@users_list=>'+str(users_list));
    except Exception as e:
        error_msg = "Unable to search for users. Please try again later."
        printlog(str(e))
    return users_list,error_msg


def list_users(email,firstName,lastName,company, scac,invitationStatus,access_token,request,supplier_context_flag):
    users_list = []    
    supplier_group_members_list = []
    supplier_group_members_dict = {}
    url = ""
    error_msg = ""
    printlog('@@@scac=>'+scac)
    printlog('@@@supplier_context_flag=>'+supplier_context_flag)
    printlog('@@@company=>'+company);
    if scac and scac != "":             
        for supplier_group_id in get_supplier_group_id_list(scac,access_token):            
            supplier_group_members_list += get_group_members(supplier_group_id,access_token)
        #Converting List to Dictionary for faster search    
        supplier_group_members_dict = {supplier_id:supplier_id for supplier_id in supplier_group_members_list}
        if not supplier_group_members_dict: 
            printlog('Returning as no scac matching groups found')		
            return users_list,error_msg
                
        #print("Supplier Member List Count: " + str(len(supplier_group_members_list)))
        
    select='id,surname,givenName,displayName,companyName,mail,externalUserState'
    filter = "userType eq 'Guest'"


    if firstName != "":
        filter+=" and startswith(givenName,'"+firstName+"')"
    if lastName != "":
        filter+=" and startswith(surname,'"+lastName+"')"
    if email !="":
        filter+=" and startswith(mail,'"+email+"')"
    printlog('@@Checking company filter..')
    if company != "" and supplier_context_flag != 'Y':
        printlog('Adding companyName filter.')
        filter+=" and startswith(companyName,'"+company+"')"
    if invitationStatus:
        filter+=" and externalUserState eq '"+"PendingAcceptance"+"'"  

    #req_params = {'$select': select, '$filter': filter, '$count': 'true'}
    printlog("#-#-#-Supplier context check")
    # check if the user has admin group assigned
    # if so restrict the search criteria only to the supplier group
    
    logged_in_user_id,logged_in_access_token,company_name = get_logged_in_user(request)
    printlog('logged_in_user_id=>'+logged_in_user_id)
    #printlog('logged_in_access_token=>'+logged_in_access_token)
    user_group_list = fetch_user_groups(logged_in_user_id,access_token)
    printlog("user_group_list==>"+str(user_group_list))
    #fetch supplier group for the user
    
    supp_group_list = fetch_user_supplier_group(logged_in_user_id,access_token)
    # check if the admin group is in the list
    printlog("#-#-#-"+os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT )
    if (os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT in user_group_list):
        printlog("#-#-#-matched supplier context" )
        printlog("#-#-#-"+str(supp_group_list))
        try:
            url = 'https://graph.microsoft.com/v1.0/groups/{}/members?$count=true&$select={}&$filter={}&$top={}'.format(get_group_id_list(supp_group_list,access_token=access_token)[0],select,filter,'999')
        except Exception as e:
            printlog("EXCEPTION forming url")            
            printlog (e)   
            error_msg = "User does not have Supplier Admin Group Linked. Please add appropriate group."
    else:
    # url = 'https://graph.microsoft.com/v1.0/users?$select={}&$filter={}&$top={}'.format(select,filter,'999')
        try:
            url = 'https://graph.microsoft.com/v1.0/groups/{}/members?$count=true&$select={}&$filter={}&$top={}'.format(get_group_id_list(group_name_list=['NAT_AZURE_BPG_ILE_USR_{}'.format(settings.ENVIRONMENT)],access_token=access_token)[0],select,filter,'999')
        except Exception as e:
            printlog("EXCEPTION forming url")            
            printlog (e)  
            error_msg = "User missing appropriate group. Please add appropriate group."
    print(url)
    req_header = {'Content-Type': 'application/json','Authorization': 'Bearer ' + access_token, 'ConsistencyLevel':'Eventual', 'Accept':'application/json;odata.metadata=none'}
    next_loop = True
    while next_loop and error_msg=="":        
        printlog("#-#-#-Calling Search API")   
        printlog("#-#-# URL=>"+url)     
        response = requests.get(url, headers=req_header)
        response_json = response.json()
        printlog("Search Response=>"+str(response_json))
        printlog('supplier_group_members_dict=>'+str(supplier_group_members_dict))
        
        if not response.ok:
            printlog('Search Response is not OK')
            printlog(response.status_code)
            if "error" in response_json:
                print(response_json["error"]["code"])
                print(response.status_code)
        else: 
            printlog('@@@In else Loop')              
            for user in response_json['value']:
                printlog('@@@In for loop')  
                try:  
                    printlog('@@@scac=>'+scac)     
                    if scac: 
                        printlog('user[id]=>'+user['id'])
                        if bool(supplier_group_members_dict) and user['id'] not in supplier_group_members_dict:                                                    
                            continue

                    user_details = UserDetails()    
                    user_details.user_id = user['id']
                    user_details.firstName = user['givenName']
                    if user_details.firstName == None:
                        user_details.firstName = user['displayName'].split()[0:][0]
                    user_details.lastName = user['surname']
                    if user_details.lastName == None:
                        user_details.lastName = user['displayName'].split()[-1:][0]
                    user_details.workEmail = user['mail']
                    user_details.company = user['companyName']
                    user_details.invitationStatus = user['externalUserState']
                    sup_details = get_sup_details(user['id'],access_token)                    
                    user_details.scac = sup_details['SCAC']                                     
                    users_list.append(user_details)
                    printlog('user_list(in loop)=>'+str(users_list))
                except Exception as e:
                    print("EXCEPTION PARSING RESPONSE")            
                    print (e)   
        if '@odata.nextLink' in response_json:
            url = response_json['@odata.nextLink']
            next_loop = True
        else:
            next_loop = False  
    return users_list,error_msg

def get_sup_details(user_id,access_token):
    sup_details = {"SCAC":""}    
    url = "https://graph.microsoft.com/v1.0/users/{}/memberOf/microsoft.graph.group".format(user_id)
    select="displayName,description"
    search = "\"displayName:NAT_AZURE_SUPPLIER_\""

    req_params = {'$select': select, '$search': search, '$count': 'true'}    
    req_header = {'Authorization': 'Bearer ' + access_token, 'ConsistencyLevel': 'Eventual'}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    
    if not response.ok:
        if "error" in response_json:
            print(response_json["error"]["code"])
            print(response.status_code)
    else:
        for groups in response_json['value']:
            if groups['displayName'].endswith("_{}".format(settings.ENVIRONMENT)):
                try:                                                          
                    description_json = json.loads(groups['description'].replace("\\","")  )   
                    sup_details['SCAC'] = description_json['SCAC']
                except Exception as e:
                    print("EXCEPTION PARSING SUPPLIER GROUP RESPONSE")            
                    print (str(e))        
    return sup_details

def get_supplier_group_id_list (scac,access_token):
    group_id_list = []
    cls_supplier_details = {}
    supplier_id = "999"
    cls_supplier_details = fetch_supplier(scac, 'SCAC')
    if cls_supplier_details['statusCode'] == 200:
        supplier_id = cls_supplier_details['j1Id']	
        printlog('Supplier Id returned => ' + supplier_id)
    else:
        printlog('No Supplier ID return by cls')
        return group_id_list
	
    url = "https://graph.microsoft.com/v1.0/groups"
    select = "id,displayName,description"
    search = "\"displayName:NAT_AZURE_SUPPLIER_"+ supplier_id +"_ILE_" + settings.ENVIRONMENT +"\""
    printlog('url=>'+url)
    printlog('search=>'+search)
    try:       

        req_params = {'$select': select, '$search': search, '$count': 'true', '$top': '999'}
        
        req_header = {'Authorization': 'Bearer ' + access_token, 'ConsistencyLevel': 'Eventual'}
        response = requests.get(url, params=req_params, headers=req_header)
        response_json = response.json() 
        printlog(str(response_json))
        
        if not response.ok:
            if "error" in response_json:
                printlog(response_json["error"]["code"])
                printlog(response.status_code)
        else:
            for groups in response_json['value']:                                                          
                try:
                    if groups['displayName'].endswith("_{}".format(settings.ENVIRONMENT)):
                        description_json = json.loads(groups['description'])  
                        if scac and str(description_json['SCAC']).lower().startswith(str(scac).lower()): 
                            printlog('selected group name '+groups['displayName'])
                            group_id_list.append(groups['id'])                   
                except Exception as e:
                    print("EXCEPTION PARSING SCAC")            
                    print (str(e))  
    except Exception as e:
        print("EXCEPTION PARSING SUPPLIER GROUP ID RESPONSE")            
        print (str(e))  
    printlog(str(group_id_list))    
    return group_id_list
    
