from django.conf import settings
from .models import UserDetails
from .graph import get_group_members,get_group_id_list,fetch_user_groups,fetch_user_supplier_group,get_logged_in_user,get_user_id
import requests
import json
from .uspslogger import printlog
import os


def search_users(UserDetails, access_token,request):    
    users_list = list_users (email = UserDetails.workEmail,firstName=UserDetails.firstName,lastName=UserDetails.lastName,company=UserDetails.company, scac=UserDetails.scac, duns=UserDetails.duns,invitationStatus=UserDetails.invitationStatus,access_token=access_token,request=request)    
    return users_list


def list_users(email,firstName,lastName,company, scac,duns,invitationStatus,access_token,request):
    users_list = []    
    supplier_group_members_list = []
    supplier_group_members_dict = {}
    if scac or duns:             
        for supplier_group_id in get_supplier_group_id_list(scac,duns,access_token):            
            supplier_group_members_list += get_group_members(supplier_group_id,access_token)
        #Converting List to Dictionary for faster search    
        supplier_group_members_dict = {supplier_id:supplier_id for supplier_id in supplier_group_members_list}
                
        #print("Supplier Member List Count: " + str(len(supplier_group_members_list)))
        
    select='id,surname,givenName,displayName,companyName,mail,externalUserState'
    filter = "userType eq 'Guest'"


    if firstName != "":
        filter+=" and startswith(givenName,'"+firstName+"')"
    if lastName != "":
        filter+=" and startswith(surname,'"+lastName+"')"
    if email !="":
        filter+=" and startswith(mail,'"+email+"')"
    if company != "":
        filter+=" and startswith(companyName,'"+company+"')"
    if invitationStatus:
        filter+=" and externalUserState eq '"+"PendingAcceptance"+"'"  

    #req_params = {'$select': select, '$filter': filter, '$count': 'true'}
    printlog("#-#-#-Supplier context check")
    # check if the user has admin group assigned
    # if so restrict the search criteria only to the supplier group
    
    logged_in_user_id,logged_in_access_token = get_logged_in_user(request);
    printlog('logged_in_user_id=>'+logged_in_user_id)
    #printlog('logged_in_access_token=>'+logged_in_access_token)
    user_group_list = fetch_user_groups(logged_in_user_id,access_token)
    printlog("user_group_list==>"+str(user_group_list))
    #fetch supplier group for the user
    
    supp_group_list = fetch_user_supplier_group(logged_in_user_id,access_token)
    # check if the admin group is in the list
    printlog("#-#-#-"+os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT )
    if (os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT in user_group_list):
        printlog("#-#-#-matched supplier context" )
        printlog("#-#-#-"+str(supp_group_list))
        url = 'https://graph.microsoft.com/v1.0/groups/{}/members?$count=true&$select={}&$filter={}&$top={}'.format(get_group_id_list(supp_group_list,access_token=access_token)[0],select,filter,'999')
    else:
    #url = 'https://graph.microsoft.com/v1.0/users?$select={}&$filter={}&$top={}'.format(select,filter,'999')
        url = 'https://graph.microsoft.com/v1.0/groups/{}/members?$count=true&$select={}&$filter={}&$top={}'.format(get_group_id_list(group_name_list=['NAT_AZURE_BPG_ILE_USR_{}'.format(settings.ENVIRONMENT)],access_token=access_token)[0],select,filter,'999')
    print(url)
    req_header = {'Content-Type': 'application/json','Authorization': 'Bearer ' + access_token, 'ConsistencyLevel':'Eventual', 'Accept':'application/json;odata.metadata=none'}
    next_loop = True
    while next_loop:        
        printlog("#-#-#-Calling Search API")   
        printlog("#-#-# URL=>"+url)     
        response = requests.get(url, headers=req_header)
        response_json = response.json()
        printlog("Search Response=>"+str(response_json))
        
        if not response.ok:
            if "error" in response_json:
                print(response_json["error"]["code"])
                print(response.status_code)
        else: 
                          
            for user in response_json['value']:
                
                try:                                                                
                    if scac or duns:                        
                        if user['id'] not in supplier_group_members_dict:                                                    
                            continue

                    user_details = UserDetails()    
                    user_details.user_id = user['id']
                    user_details.firstName = user['givenName']
                    if user_details.firstName == None:
                        user_details.firstName = user['displayName'].split()[0:][0]
                    user_details.lastName = user['surname']
                    if user_details.lastName == None:
                        user_details.lastName = user['displayName'].split()[-1:][0]
                    user_details.workEmail = user['mail']
                    user_details.company = user['companyName']
                    user_details.invitationStatus = user['externalUserState']
                    sup_details = get_sup_details(user['id'],access_token)                    
                    user_details.scac = sup_details['SCAC']
                    user_details.duns = sup_details['DUNS']                    
                    users_list.append(user_details)
                except Exception as e:
                    print("EXCEPTION PARSING RESPONSE")            
                    print (e)   
        if '@odata.nextLink' in response_json:
            url = response_json['@odata.nextLink']
            next_loop = True
        else:
            next_loop = False      
    return users_list

def get_sup_details(user_id,access_token):
    sup_details = {"SCAC":"","DUNS":""}    
    url = "https://graph.microsoft.com/v1.0/users/{}/memberOf/microsoft.graph.group".format(user_id)
    select="displayName,description"
    search = "\"displayName:NAT_AZURE_SUPPLIER_\""

    req_params = {'$select': select, '$search': search, '$count': 'true'}    
    req_header = {'Authorization': 'Bearer ' + access_token, 'ConsistencyLevel': 'Eventual'}
    response = requests.get(url, params=req_params, headers=req_header)
    response_json = response.json()
    
    if not response.ok:
        if "error" in response_json:
            print(response_json["error"]["code"])
            print(response.status_code)
    else:
        for groups in response_json['value']:
            if groups['displayName'].endswith("_{}".format(settings.ENVIRONMENT)):
                try:                                                          
                    description_json = json.loads(groups['description'].replace("\\","")  )   
                    sup_details['SCAC'] = description_json['SCAC']
                    sup_details['DUNS'] = description_json['DUNS']
                except Exception as e:
                    print("EXCEPTION PARSING SUPPLIER GROUP RESPONSE")            
                    print (str(e))        
    return sup_details

def get_supplier_group_id_list (scac,duns,access_token):
    group_id_list = []
    url = "https://graph.microsoft.com/v1.0/groups"
    select = "id,displayName,description"
    search = "\"displayName:NAT_AZURE_SUPPLIER_\""
    try:
        '''if scac:
            search += ' AND \"description:\\\"SCAC\\\": \\\"{}\\\"\"'.format(scac)
        if duns:
            search += ' AND \"description:\\\"DUNS\\\": \\\"{}\\\"\"'.format(duns)
        '''

        req_params = {'$select': select, '$search': search, '$count': 'true', '$top': '999'}
        
        req_header = {'Authorization': 'Bearer ' + access_token, 'ConsistencyLevel': 'Eventual'}
        response = requests.get(url, params=req_params, headers=req_header)
        response_json = response.json()        
        
        if not response.ok:
            if "error" in response_json:
                print(response_json["error"]["code"])
                print(response.status_code)
        else:
            for groups in response_json['value']:                                                          
                try:
                    if groups['displayName'].endswith("_{}".format(settings.ENVIRONMENT)):
                        description_json = json.loads(groups['description'])                          
                        if scac and duns and str(description_json['SCAC']).lower().startswith(str(scac).lower()) and str(description_json['DUNS']).startswith(str(duns)): 
                            group_id_list.append(groups['id'])
                        elif scac and not duns and str(description_json['SCAC']).lower().startswith(str(scac).lower()):
                            group_id_list.append(groups['id'])
                        elif duns and not scac and str(description_json['DUNS']).startswith(str(duns)):
                            group_id_list.append(groups['id'])                     
                except Exception as e:
                    print("EXCEPTION PARSING SCAC DUNS")            
                    print (str(e))  
    except Exception as e:
        print("EXCEPTION PARSING SUPPLIER GROUP ID RESPONSE")            
        print (str(e))        
    return group_id_list
    
