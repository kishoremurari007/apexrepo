from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.conf import settings


from django.shortcuts import render

from .uspsOtp import *
from .uspsMail import *

from .uspsSearch import search_users
from .models import RegistrationForm, UserDetails, UserMgmtSearchForm, UserAccessControlForm, UserRegisterAppForm, UserRegisterAppSuppForm
from .graph import *  # does_user_exists, send_invitation_to_user,update_user_details,get_group_id_list,add_groups_to_user,get_user_status, set_user_status, init_user_access_control,groups_assign_to_user, groups_unassign_to_user, fetch_user_groups, get_supplier_group_id, get_extension_attributes, fetch_invitation_access_token, fetch_access_token
from .clsgraph import fetch_supplier_wrapper, create_supuser_upsert,fetch_supplier

# Import Custom Logger Module
from .uspslogger import printlog, setlogenv

# Logout Function


def logout(request):
    # Redirect to the logout endpoint of Azure Web
    printlog("Logout Initiated")
    return HttpResponseRedirect("/.auth/logout")

# Main Init Function

def usermgmt(request):
    printlog("INSIDE usermgmt")
    error_msg = ""
    setlogenv(request)
    #STAF FLAG
    STAF_FLAG = "N"
    SUPPLIER_CONTEXT_FLAG = "N"
    CLEAR_FLAG = "N"
    # Check the supplier context
    PAGE_ACCESS_FLAG = "N" #Check whether Page is accessible by user
    printlog("#-#-#-Supplier context check")
    # check if the user has admin group assigned
    # if so restrict the search criteria only to the supplier group
    
    logged_in_user_id,logged_in_access_token,company_name = get_logged_in_user(request)
    printlog('logged_in_user_id=>'+logged_in_user_id)
    printlog('company_name=>'+company_name)
    #printlog('logged_in_access_token=>'+logged_in_access_token)
    if logged_in_user_id == 'null':
        form = UserMgmtSearchForm()
        printlog('Error in fetching logged in user credentials due to acccess/permission issue') 
        PAGE_ACCESS_FLAG = "E"		
        return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL,'SUPPLIER_CONTEXT_FLAG':SUPPLIER_CONTEXT_FLAG, 'PAGE_ACCESS_FLAG':PAGE_ACCESS_FLAG})	
    # Fetch the Access Token
    access_token = fetch_access_token()
    user_group_list = fetch_user_groups(logged_in_user_id,access_token)
    #fetch supplier group for the user
    
    supp_group_list = fetch_user_supplier_group(logged_in_user_id,access_token)
    printlog('!!!!!!Printing supplier group list !!!!!')
    for value in supp_group_list:
        printlog(value)
    supp_group_details = get_supplier_group_details(' '.join(supp_group_list),access_token);
    printlog('!!!!!!Printing supp_group_details !!!!!')
    printlog(supp_group_details['SCAC'])
    # check if the admin group is in the list
    printlog("#-#-#-"+os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT )
    if (os.environ.get("SUPP_ADMIN_GROUP")+"_"+settings.ENVIRONMENT in user_group_list):
        printlog("#-#-#-matched supplier context" )
        SUPPLIER_CONTEXT_FLAG = "Y"

    #Check if User has access to Page    
    PAGE_ACCESS_GROUP_LIST = settings.PAGE_ACCESS_GROUPS.split(",")
    for PAGE_ACCESS_GROUP_NAME in PAGE_ACCESS_GROUP_LIST:
        if PAGE_ACCESS_GROUP_NAME in user_group_list:
            PAGE_ACCESS_FLAG = "Y"


    # if this is a GET request present a Blank Form
    print('Supplier Context Flag@=@=@=@=@=@= =>'+SUPPLIER_CONTEXT_FLAG);
    print('logged_in_user_id@=@=@=@=@=@= =>'+logged_in_user_id); 
    if request.method == 'GET':
        form = UserMgmtSearchForm()
        return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL,'SUPPLIER_CONTEXT_FLAG':SUPPLIER_CONTEXT_FLAG,'PAGE_ACCESS_FLAG':PAGE_ACCESS_FLAG})
    # if this is a POST request we need to process the form data
    elif request.method == 'POST':
        printlog(request.POST)
        response_message = {"validation_error": "",
                            "invitation_message": ""}
        if (request.POST.get('registerUserToggle', 'NO') == "YES"):
            form = RegistrationForm(data=request.POST) 
            if SUPPLIER_CONTEXT_FLAG  == "Y" :
                printlog('==>Supplier Context is Y. Setting the required properties to False')
                form.fields['scac'].required = False 
                form.fields['company'].required = False            
                form.fields['firstName'].required = False
                form.fields['lastName'].required = False
                form.fields['workEmail'].required = False
        else:
            form = UserMgmtSearchForm(data=request.POST)   
        
        # check whether it's valid:
        if form.is_valid():
            printlog("Form Valid")

            # Fetch the Access Token
            access_token = fetch_access_token()

            # Process the data in form.cleaned_data as required
            user_details = UserDetails()
            user_details.firstName = form.cleaned_data['firstName'].strip()
            user_details.lastName = form.cleaned_data['lastName'].strip()
            user_details.workEmail = form.cleaned_data['workEmail'].strip()
            if SUPPLIER_CONTEXT_FLAG  == "Y" :
               printlog('==>Supplier Context is Y. Assigning company_name and scac') 
               printlog(company_name)
               printlog(supp_group_details['SCAC'])
               user_details.company = company_name
               user_details.scac = supp_group_details['SCAC']
               CLEAR_FLAG = "N"
            else:
                user_details.company = form.cleaned_data['company'].strip()
                user_details.scac = form.cleaned_data['scac'].strip()
            #user_details.duns = form.cleaned_data['duns'].strip()
            user_details.responseText = ""
            user_details.user_id = ""

            if (request.POST.get('registerUserToggle', 'NO') == "YES"):
                printlog("Registering User")
                if SUPPLIER_CONTEXT_FLAG  == "Y" :
                    applications_list_form = UserRegisterAppSuppForm(data=request.POST) 
                    user_details.apexId = ''
                else:
                    user_details.apexId = form.cleaned_data['apexId'].strip()
                    applications_list_form = UserRegisterAppForm(data=request.POST) 
                applications_list = []
                groups_list = []

                printlog("APEXID: "+ str(user_details.apexId))

                # Read JSON File
                ext_json_data = read_extension_attributes_file()

                # Loop through each fields in Form
                print("LOOPING APPLICATION FIELD")
                if applications_list_form.is_valid():
                    # Iterate through the fields and print their values
                    for field_name, field_value in applications_list_form.cleaned_data.items():
                        print(f"{field_name}: {field_value}")
                for fields in applications_list_form:
                    if fields.value() is not None and fields.value() != '':
                        if 'data-group-application-code' in fields.field.widget.attrs and fields.value().lower()=="true":
                                if fields.field.widget.attrs['data-group-application-code'] in ('STAF','FA', 'ILERPT') and STAF_FLAG=='N':
                                    STAF_FLAG = 'Y'
                                    printlog("STAF Flag is ON")
                                elif fields.field.widget.attrs['data-group-application-code'] in ('CLEAR_SUPPLIER','CLEAR_TRM') and STAF_FLAG=='N':
                                    CLEAR_FLAG = "Y"
                                    printlog("CLEAR Flag is ON")
                                
                                custom_assignments = get_custom_assignments(
                                    ext_json_data, fields.field.widget.attrs['data-group-application-code'])
                                print(custom_assignments)
                                applications_list.append(fields.field.widget.attrs['data-group-application-code'])                    
                                if custom_assignments['ADMIN_FLAG'] == "Y":
                                    groups_list.append(custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT) 
                                else:
                                    groups_list.append(custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT)                                      

                print(applications_list)
                print(groups_list)


                # Fetch the Invitation Access Token
                invitation_access_token = fetch_invitation_access_token()
                user_details = does_user_exists(user_details, access_token)

                if (user_details.user_id != ""):
                    # If User is already assigned the BPG Group, Exit the Process.
                    if ('NAT_AZURE_BPG_ILE_USR_{}'.format(settings.ENVIRONMENT) in fetch_user_groups(user_id=user_details.user_id, access_token=access_token)):
                        printlog("User already assigned to Group")
                        response_message['validation_error'] = "User Account with Email " + \
                            user_details.workEmail + ": already exists."
                        #return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message": response_message})
                        return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                
                printlog("@@@Initializing Supplier Group Variables.")
                supplier_group_name=""
                supplier_group_description = ""
                supplier_result = {}
                supplier_result['clsj1Id'] = ""
                cls_supplier_details = {}
                cls_supplier_details['statusCode'] = 999
                printlog("@@@STAF_FLAG=>"+STAF_FLAG)
                if STAF_FLAG == "Y" or SUPPLIER_CONTEXT_FLAG  == "Y":
                    try:
                        #Fetch Supplier Details from CLS
                        printlog("Fetch Supplier Details from CLS")
                        cls_supplier_details = fetch_supplier(user_details.scac, 'SCAC')
                        print ("fetch_supplier statusCode: "+str(cls_supplier_details['statusCode']))                        
                        if cls_supplier_details['statusCode'] == 200:
                            supplier_result ['clsj1Id'] = cls_supplier_details['j1Id']
                            supplier_result ['clserpNum'] = cls_supplier_details['erpNumber']
                            supplier_result ['userCreated'] = "N"
                            supplier_result ['clsapexId'] = cls_supplier_details['apexSupplierNumber']
                        #if apexSupplierNumber is returned from CLS
                        if 'apexSupplierNumber' in cls_supplier_details and cls_supplier_details['apexSupplierNumber'] and cls_supplier_details['apexSupplierNumber'] != "null":
                            print ("ApexSupplierNumber exists in CLS: " + str(cls_supplier_details['apexSupplierNumber']))
                            user_details.apexId = str(cls_supplier_details['apexSupplierNumber'])
                        #If apexId was entered by user
                        elif user_details.apexId != '':
                            pass
                        elif STAF_FLAG == "Y":
                            response_message['validation_error'] = "Registration cannot be completed without APEX ID. Please contact ILECLEAR@usps.gov."
                            return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                    except Exception as e:
                        #Return Error for Exception
                        if user_details.apexId == '' and STAF_FLAG == "Y":
                            response_message['validation_error'] = "Registration cannot be completed without APEX ID. Please contact ILECLEAR@usps.gov."
                            return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                
                if cls_supplier_details['statusCode'] != 200: #If FETCH_SUPPLIER Failed, call wrapper function to create supplier
                    print("Fetch Supplier Failed. Calling fetch_supplier_wrapper.")
                    #Uncomment in real USPS
                    supplier_result = fetch_supplier_wrapper(user_details)
                    
                    #supplier_result = {} #Only for USPS Test
                    #supplier_result['clsj1Id'] = '9999' #Only for USPS Tests
                    #supplier_result['userCreated'] = 'Y' #Only for USPS Test
                    
                    if 'clsapexId' in supplier_result and supplier_result['clsapexId'] != "" and supplier_result['clsapexId'] != "null":
                        user_details.apexId = supplier_result['clsapexId']


                if ('clsj1Id' in supplier_result and supplier_result['clsj1Id'] == ""):
                    response_message['validation_error']=supplier_result['statusMessage']
                    #return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message":response_message})  
                    printlog("supplier_result clsj1Id is null..returning for validation error")
                    return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                else:                        
                    supplier_group_name = "NAT_AZURE_SUPPLIER_{}_ILE_{}".format(supplier_result['clsj1Id'],settings.ENVIRONMENT)                                                                    
                    #Generate Supplier Group Details for STAF
                    printlog("Generate Supplier Group Details for STAF")
                    supplier_group_description = {
                        "supplierName": user_details.company,
                        "supplierDomainName": user_details.workEmail.split('@')[1],
                        "supplierID": supplier_result['clsj1Id'],
                        "APEXID": user_details.apexId,
                        "SCAC": user_details.scac,
                        #"DUNS": user_details.duns
                    }
                    printlog(supplier_group_description)                     

                    #If Supplier Admin Exists, respond with an Error Message
                    printlog("If Supplier Admin Exists, respond with an Error Message")
                    if 1 == 2 and supplier_result['userCreated'] == "N" and SUPPLIER_CONTEXT_FLAG == "N" and does_supplier_admin_exist (supplier_group_name=supplier_group_name,supplier_admin_group=settings.AZURE_CLS_ADMIN_GROUP,access_token=access_token):
                        response_message['validation_error']='Your company is already registered with USPS, please contact your company\'s administrator for access.'
                        #return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message":response_message})                        
                        return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                    else:
                        printlog('In else statement')
                        printlog('supplier_result(usercreated)=>'+supplier_result['userCreated'])
                        printlog('CLEAR_FLAG=>'+CLEAR_FLAG);
                        if supplier_result['userCreated'] == "N" and CLEAR_FLAG =="Y":
                            #If User was not created by CLS, create User only for CLEAR
                            try:
                                csuapi_response = create_supuser_upsert(
                                    supplier_result['clserpNum'], supplier_result['clsj1Id'], True, user_details.firstName, user_details.lastName, user_details.workEmail)
                                print('Supplier User Upsert API Response')
                                print(csuapi_response)
                                #statusCode = csuapi_response['statusCode']
                                if (csuapi_response['statusCode'] == 204):
                                    # create_supuser_upsert success
                                    print(csuapi_response['statusDesc'])
                                    #Set UserCreated as Y
                                    supplier_result['userCreated'] = "Y"
                                elif (csuapi_response['statusCode'] == 400):
                                    # create_supuser_upsert validation error
                                    print(csuapi_response['statusDesc'])
                                    print(csuapi_response['errorDetails'])
                                else:
                                    # Other exception
                                    print(csuapi_response['statusDesc'])                                        
                            except Exception as e:
                                print("Exception while calling CLS API Supplier User Upsert - "+str(e))
                            #If User is not created, STOP
                            if (supplier_result['userCreated'] == "N" and CLEAR_FLAG =="Y"):
                                    response_message['validation_error']='Error encountered while creating user. Please contact USPS Helpdesk.'
                                    #return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message":response_message})                        
                                    return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                            
                    #user_details=does_user_exists (user_details,access_token) #Commented as no need to call it twice
                    if (user_details.user_id == ""):
                        user_details=send_invitation_to_user (user_details,invitation_access_token)
                        registerUserMessage = "An invitation was sent to: " + user_details.workEmail
                    else:                        
                        registerUserMessage = "Logistics Gateway Access has been granted to " + user_details.workEmail + ". Account is ready for use."

                    extension_attributes=get_extension_attributes(user_details.user_id, user_details.company,supplier_result['clsj1Id'],applications_list,user_details.apexId,access_token)                    
                    print("****EXTENSION ATTRIBUTES****")
                    printlog(extension_attributes)
                    if user_details.user_id != "":
                        add_user_to_administrative_unit(unit_name=settings.ADMINISTRATIVE_UNIT_NAME, user_id=user_details.user_id, access_token=invitation_access_token)
                        user_details_update_response = update_user_details(user_details.user_id,user_details.firstName,user_details.lastName,user_details.company,"",extension_attributes,access_token)
                        printlog(user_details_update_response)
                        groups_list = get_group_id_list(group_name_list=groups_list,access_token=access_token)
                        
                        groups_list=groups_list+get_group_id_list(group_name_list=None,access_token=access_token)#Default Groups
                        
                        groups_list.append(get_supplier_group_id (supplier_group_name, supplier_group_description,access_token))
                        print("****GROUPS ADDED****")
                        print(groups_list)
                        group_assignment_result=add_groups_to_user(user_details.user_id,groups_list,access_token)
                    #return render(request, "bpglgusermgmt.html", {'form': search_form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, 'registerUserMessage': registerUserMessage})
                    return HttpResponse(registerUserMessage, content_type="text/plain", status=200)
            else:  # Search for User
                user_details.invitationStatus = form.cleaned_data['pendingInvitationFlag']
                users_list, error_msg = search_users(user_details, access_token,request,SUPPLIER_CONTEXT_FLAG)
                printlog('Supplier Context Flag =========>(1)'+SUPPLIER_CONTEXT_FLAG)
                printlog('error_msg: '+ error_msg)                
                return render(request, "bpglgusermgmt.html", {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "users_list": users_list,'SUPPLIER_CONTEXT_FLAG':SUPPLIER_CONTEXT_FLAG,'PAGE_ACCESS_FLAG':PAGE_ACCESS_FLAG, 'ERROR_MSG':error_msg})                
        else:  # If form is not Valid
            #response_message['validation_error'] = "Please fill required fields"
            printlog('Supplier Context Flag =========>(2)'+SUPPLIER_CONTEXT_FLAG)
            return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message": response_message,'SUPPLIER_CONTEXT_FLAG':SUPPLIER_CONTEXT_FLAG, 'PAGE_ACCESS_FLAG':PAGE_ACCESS_FLAG})
    printlog('Supplier Context Flag =========>(3)'+SUPPLIER_CONTEXT_FLAG)
    return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL,'SUPPLIER_CONTEXT_FLAG':SUPPLIER_CONTEXT_FLAG, 'PAGE_ACCESS_FLAG':PAGE_ACCESS_FLAG})


def resendinvite(request):
    setlogenv(request)
    if request.method == 'POST':
        # Fetch the Invitation Access Token
        invitation_access_token = fetch_invitation_access_token()

        user_details = UserDetails()
        user_details.firstName = request.POST['firstName']
        user_details.lastName = request.POST['lastName']
        user_details.workEmail = request.POST['workEmail']
        user_details = send_invitation_to_user(
            user_details, invitation_access_token)
        response_message = "An invitation has been sent to " + user_details.workEmail + \
            ".\nPlease check your mails and Accept the invitation."
        return HttpResponse(response_message, content_type="text/plain", status=200)


def get_user_access_control_form(request):
    setlogenv(request)

    if request.method == 'GET':
        # Fetch the Access Token
        access_token = fetch_access_token()

        form_initial = {}
        list_form_initial = []
        clear_extension_name_list = []

        form = UserAccessControlForm()
        active_flag = get_user_status(request.GET['user_id'], access_token)
        form_initial['activeUserFlag'] = active_flag

        list_form_initial.append({
            'fieldName': 'activeUserFlag',
            "fieldValue": active_flag
        })

        

        # Get Current List of Groups assigned to User
        user_group_list = fetch_user_groups(
            request.GET.get('user_id'), access_token)

        # Read JSON File
        ext_json_data = read_extension_attributes_file()

        for fields in form:

            if fields.name != 'activeUserFlag':
                if 'data-group-application-code' in fields.field.widget.attrs:
                    # Get Custom Extension Attribute and Group for the Application Code
                    custom_assignments = get_custom_assignments(
                        ext_json_data, fields.field.widget.attrs['data-group-application-code'])

                    if custom_assignments:
                        
                        
                        # if Custom Assignment Group is already assigned set value as True
                        if (custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT in user_group_list) or (custom_assignments['ADMIN_FLAG'] == 'Y' and custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT in user_group_list):                            

                            # If Application Code is CLEAR append to CLEAR Extension Attribute Name List
                            """if fields.field.widget.attrs['data-group-application-code'] in ['CLEAR_TRM','CLEAR_SUPPLIER']:                               
                                clear_extension_name_list.append('extension_{}_ILE_Alternate_UserID_{}'.format(custom_assignments['BPG_APPLICATION_ID'], custom_assignments['ALTERNATE_USER_ID']))
                                clear_extension_name = 'extension_{}_ILE_Alternate_UserID_{}'.format(custom_assignments['BPG_APPLICATION_ID'], custom_assignments['ALTERNATE_USER_ID'])
                                clear_extension_attribute_values=fetch_user_extension_attributes(user_id=request.GET.get('user_id'),ext_attr_list=[clear_extension_name],access_token=access_token)
                                print(clear_extension_attribute_values)
                                if clear_extension_name in clear_extension_attribute_values:
                                    try:
                                        if clear_extension_attribute_values[clear_extension_name].split('|')[4] == 'TRUE':                                            
                                            fieldValue = True
                                        else:
                                            fieldValue = False
                                    except Exception as e:
                                        print(str(e))
                            else:"""
                            fieldValue = True
                        else:
                            fieldValue = False
                       
                        list_form_initial.append({
                            'fieldName': fields.name,
                            "fieldValue": fieldValue
                        })


        for fields in list_form_initial:
            form_initial[fields['fieldName']] = fields['fieldValue']

        form.initial = form_initial

        context = {
            'form': form, "user_id": request.GET['user_id']
        }
    elif request.method == 'POST': #Setting Up Groups
        # Fetch the Access Token
        access_token = fetch_access_token()

        form = UserAccessControlForm(data=request.POST)
        printlog(request.POST)
        if form.is_valid():
            printlog("Valid Form")
            printlog(request.POST.get('user_id'))
            printlog(form.cleaned_data)  

            #STAF FLAG
            STAF_FLAG = "N"          
            CLEAR_FLAG = "N"

            context = {'form': form}
            printlog(form.errors)
            #return render(request, 'useraccesscontrolform.html', context)            

            set_user_status(request.POST.get('user_id'),
                            form.cleaned_data['activeUserFlag'], access_token)

            if form.cleaned_data['activeUserFlag'] == True and form.cleaned_data['resendInvitationFlag'] == True:
                user_details = UserDetails()
                user_details.firstName = request.POST['first_name']
                user_details.lastName = request.POST['last_name']
                user_details.workEmail = request.POST['work_email']
                # Fetch the Invitation Access Token
                invitation_access_token = fetch_invitation_access_token()
                user_details = send_invitation_to_user(
                    user_details, invitation_access_token)

            groups_to_remove = []
            groups_to_add = []
            extension_attributes_data = {}

            adminFlag = form.cleaned_data['adminFlag']

            # Get Current List of Groups assigned to User
            user_group_list = fetch_user_groups(
                request.POST.get('user_id'), access_token)

            # Get the CLS Supplier ID From Group List to be used Later for Extension Attribute Update
            try:
                supplier_id_list = [
                    x for x in user_group_list if x.startswith('NAT_AZURE_SUPPLIER_') and x.endswith(settings.ENVIRONMENT)]
                supplier_id = supplier_id_list[0].replace(
                    'NAT_AZURE_SUPPLIER_', '').replace('_ILE_'+settings.ENVIRONMENT, '')
                supplier_group_name = supplier_id_list[0]
            except Exception as e:
                print(str(e))
                supplier_id = ""
                supplier_group_name = ""

            printlog("Supplier Group Name: " + str(supplier_group_name))
            printlog("Supplier ID: " + str(supplier_id))

            # Read JSON File
            ext_json_data = read_extension_attributes_file()
            #Get GUID
            guid = get_guid (request.POST.get('user_id') ,get_custom_assignments(ext_json_data,"ILERPT")['EXTENSION_ATTRIBUTE_NAME'],access_token)

            #CLEAR Group Name (to be used later to remove Group from user if both CLEAR access are removed)                        
            clear_group_name = get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT     
            clear_supplier_ext_attr_name =  'extension_{}_ILE_Alternate_UserID_{}'.format(get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['BPG_APPLICATION_ID'] , get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['ALTERNATE_USER_ID'] )
            clear_trm_ext_attr_name =  'extension_{}_ILE_Alternate_UserID_{}'.format(get_custom_assignments(ext_json_data,"CLEAR_TRM")['BPG_APPLICATION_ID'] , get_custom_assignments(ext_json_data,"CLEAR_TRM")['ALTERNATE_USER_ID'] )           
            clear_supplier_old_ext_attr_name =  'extension_{}_ILE_Alternate_UserID_4'.format(get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['BPG_APPLICATION_ID'])
            staf_group_name = get_custom_assignments(ext_json_data,"STAF")['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT     
            staf_ext_attr_name =  'extension_{}_ILE_Alternate_UserID_{}'.format(get_custom_assignments(ext_json_data,"STAF")['BPG_APPLICATION_ID'], get_custom_assignments(ext_json_data,"STAF")['ALTERNATE_USER_ID'] )
            staf_old_ext_attr_name =  'extension_{}_ILE_Alternate_UserID_3'.format(get_custom_assignments(ext_json_data,"STAF")['BPG_APPLICATION_ID'])
            printlog("staf_group_name: " + staf_group_name + " staf_ext_attr_name: " + staf_ext_attr_name + " staf_old_ext_attr_name " +  staf_old_ext_attr_name + " clear_supplier_old_ext_attr_name: " + clear_supplier_old_ext_attr_name + " clear_group_name " + clear_group_name)            

            # Loop through each fields in Form
            print("Checking STAF Flag")
            for fields in form:
                if 'data-group-application-code' in fields.field.widget.attrs and fields.value() is not None and fields.value().lower()=="true" and fields.field.widget.attrs['data-group-application-code'] in ('STAF','FA', 'ILERPT') and STAF_FLAG == 'N':
                    STAF_FLAG = 'Y'                    
                    printlog("STAF Flag is ON")
                elif 'data-group-application-code' in fields.field.widget.attrs and fields.value() is not None and fields.value().lower()=="true" and fields.field.widget.attrs['data-group-application-code'] in ('CLEAR_SUPPLIER','CLEAR_TRM') and CLEAR_FLAG == 'N':
                    CLEAR_FLAG = "Y"
                    printlog("CLEAR Flag is ON")
                

            
            #Generate Supplier Group Details for STAF
            try:
                #Fetch Apex ID from Supplier Group
                supplier_group_details = get_supplier_group_details(supplier_group_name,access_token)
                print(supplier_group_details)
                if supplier_group_details['APEXID'] == '' or supplier_group_details['APEXID'] == "null":
                    #Fetch Supplier Details from CLS
                    cls_supplier_details = fetch_supplier(supplier_group_details['SCAC'], 'SCAC')
                    if 'apexSupplierNumber' in cls_supplier_details and cls_supplier_details['apexSupplierNumber']:
                        supplier_group_details['APEXID'] = cls_supplier_details['apexSupplierNumber']
                        supplier_group_description = supplier_group_details['DESCRIPTION'] .replace('"APEXID": ""','"APEXID": "{}"'.format(supplier_group_details['APEXID'] ))
                        update_group_description(supplier_group_details['ID'],supplier_group_description,access_token)
                        printlog(supplier_group_description)                                                                   
            except Exception as e:
                supplier_group_details['APEXID']=""
                print(e)
                    
            if STAF_FLAG == "Y" and ( supplier_group_details['APEXID'] == '' or supplier_group_details['APEXID'] == "null"):
                validation_error = "Registration cannot be completed without APEX ID. Please contact ILECLEAR@usps.gov."
                print(validation_error)
                return HttpResponse(validation_error, content_type="text/plain", status=200)



                                


            # Get TMS Application Details
            printlog('Get TMS Application Details ')
            custom_assignments_tms = get_custom_assignments(ext_json_data, 'TMS')    
            tms_extattr_added = 'N'
            # Loop through each fields in Form
            for fields in form:

                if 'data-group-application-code' in fields.field.widget.attrs:

                    # Get Custom Extension Attribute and Group for the Application Code
                    custom_assignments = get_custom_assignments(
                        ext_json_data, fields.field.widget.attrs['data-group-application-code'])
                                    

                    if custom_assignments:
                        # TRUE Means add the Group                        
                        if (form.cleaned_data[fields.name]):
                            
                            if custom_assignments['APPLICATION_CODE'] in ['CLEAR_SUPPLIER','CLEAR_TRM']:
                                # Always Add Extension Attributes irrespective of group for CLEAR
                                if supplier_id and custom_assignments['EXTENSION_ATTRIBUTE_NAME']:
                                    extension_attributes_data['extension_{}_ILE_Alternate_UserID_{}'.format(custom_assignments['BPG_APPLICATION_ID'], custom_assignments['ALTERNATE_USER_ID'])] = "{}|{}||{}|TRUE|{}".format(
                                        custom_assignments['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)
                                    extension_attributes_data[custom_assignments['EXTENSION_ATTRIBUTE_NAME']] = guid
                                    # Make an upsert call to create supplier user using CLS API in CLEAR
                                    printlog('~~~~~@@@CLEAR API CALL FOR SPECIAL HANDLING@@@@~~~~')
 
                                    #printlog('supplier_result[clserpNum] '+supplier_result['clserpNum'])
                                    #printlog('supplier_result[clsj1Id] '+supplier_result['clsj1Id'])
                                    printlog('firstName '+request.POST['first_name'])
                                    printlog('lastName '+request.POST['last_name'])
                                    printlog('workEmail '+request.POST['work_email'])
                                    printlog('scac '+supplier_group_details['SCAC'])
                                    
                                    try:
                                        #Fetch Supplier Details from CLS
                                        printlog("Fetch Supplier Details from CLS")
                                        cls_supplier_details_upd = {}
                                        supplier_result_upd = {}
                                        cls_supplier_details_upd = fetch_supplier(supplier_group_details['SCAC'], 'SCAC')
                                        print ("fetch_supplier statusCode: "+str(cls_supplier_details_upd['statusCode']))                        
                                        if cls_supplier_details_upd['statusCode'] == 200:
                                            supplier_result_upd ['clsj1Id'] = cls_supplier_details_upd['j1Id']
                                            supplier_result_upd ['clserpNum'] = cls_supplier_details_upd['erpNumber']
                                            supplier_result_upd ['userCreated'] = "N"
                                            supplier_result_upd ['clsapexId'] = cls_supplier_details_upd['apexSupplierNumber']
                                            csuapi_response_upd = create_supuser_upsert(
                                            supplier_result_upd['clserpNum'], supplier_result_upd['clsj1Id'], True, request.POST['first_name'], request.POST['last_name'],request.POST['work_email'])
                                            print('@@@@Supplier User Upsert API Response')
                                            print(csuapi_response_upd)
                                            #statusCode = csuapi_response['statusCode']
                                        if (csuapi_response_upd['statusCode'] == 204):
                                            printlog('create_supuser_upsert success')
                                            # create_supuser_upsert success
                                            print(csuapi_response_upd['statusDesc'])
                                            printlog('Set UserCreated as Y')
                                            #Set UserCreated as Y
                                            supplier_result_upd['userCreated'] = "Y"
                                        elif (csuapi_response_upd['statusCode'] == 400):
                                            # create_supuser_upsert validation error
                                            printlog('create_supuser_upsert validation error')
                                            print(csuapi_response_upd['statusDesc'])
                                            print(csuapi_response_upd['errorDetails'])
                                        else:
                                            printlog('Other exception')
                                            # Other exception
                                            print(csuapi_response_upd['statusDesc'])                                        
                                    except Exception as e:
                                            printlog("Exception while calling CLS API Supplier User Upsert - "+str(e))
                                            #If User is not created, STOP
                                            if (supplier_result_upd['userCreated'] == "N" ):
                                                printlog('If User is not created, STOP')
                                                response_message['validation_error']='Error encountered while creating user in CLS. Please contact USPS Helpdesk.'
                                                #return render(request, 'bpglgusermgmt.html', {'form': form, 'BPG_LOGIN_URL': settings.BPG_LOGIN_URL, "response_message":response_message})                        
                                                return HttpResponse(response_message['validation_error'], content_type="text/plain", status=200)
                                                # END Upsert Call
                            if custom_assignments['APPLICATION_CODE'] in ['FA','ILERPT']: 
                                printlog('custom_assigments match to '+custom_assignments['APPLICATION_CODE'])
                                printlog('setting extension_attributes_data of value '+custom_assignments_tms['EXTENSION_ATTRIBUTE_NAME']+' to '+guid)
                                tms_extattr_added = 'Y'
                                extension_attributes_data[custom_assignments_tms['EXTENSION_ATTRIBUTE_NAME']] = guid    

                            # Add group if not already in Group List
                            if custom_assignments['ADMIN_FLAG'] == 'N' and custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT not in user_group_list:
                                print("ADD GROUP " + custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT)
                                groups_to_add.append(
                                    custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT)

                                # Add Extension Attributes as well
                                if supplier_id and custom_assignments['EXTENSION_ATTRIBUTE_NAME']:
                                    extension_attributes_data['extension_{}_ILE_Alternate_UserID_{}'.format(custom_assignments['BPG_APPLICATION_ID'], custom_assignments['ALTERNATE_USER_ID'])] = "{}|{}|{}|{}|TRUE|{}".format(
                                        custom_assignments['APPLICATION_CODE'], guid, supplier_group_details['APEXID'],request.POST.get('company'), supplier_id)
                                    if custom_assignments['APPLICATION_CODE'] in ('STAF'):
                                        extension_attributes_data[custom_assignments['EXTENSION_ATTRIBUTE_NAME']] = "{}|{}|{}".format(
                                            guid, supplier_group_details['APEXID'], request.POST.get('company'))
                                    else:
                                        extension_attributes_data[custom_assignments['EXTENSION_ATTRIBUTE_NAME']] = guid

                            if (adminFlag):
                                if custom_assignments['ADMIN_FLAG'] == 'Y' and custom_assignments['USER_GROUP_NAME']+ settings.ENVIRONMENT not in user_group_list:
                                    #print("ADD GROUP " + custom_assignments['USER_GROUP_NAME']+'_ADM_'+settings.ENVIRONMENT)
                                    groups_to_add.append(
                                        custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT)
                        else:  # Remove from Group
                            # Remove Group if present in Group List and does not belong to CLEAR

                            if custom_assignments['ADMIN_FLAG'] == 'N' and custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT in user_group_list and custom_assignments['APPLICATION_CODE'] not in ['CLEAR_SUPPLIER','CLEAR_TRM']:
                                #print("REMOVE GROUP " + custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT)
                                groups_to_remove.append(
                                    custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT)
                            if custom_assignments['ADMIN_FLAG'] == 'Y' and custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT in user_group_list and custom_assignments['APPLICATION_CODE'] not in ['CLEAR_SUPPLIER','CLEAR_TRM']:
                                #print("REMOVE GROUP " + custom_assignments['USER_GROUP_NAME']+'_ADM_'+settings.ENVIRONMENT)
                                groups_to_remove.append(
                                    custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT)
                            # Remove Extension Attributes as well (Only if removing the Group)                            
                            if custom_assignments['USER_GROUP_NAME']+'_USR_'+settings.ENVIRONMENT in user_group_list or (custom_assignments['ADMIN_FLAG'] == 'Y' and custom_assignments['USER_GROUP_NAME']+settings.ENVIRONMENT) in user_group_list:
                                if supplier_id and custom_assignments['EXTENSION_ATTRIBUTE_NAME']:
                                    extension_attributes_data['extension_{}_ILE_Alternate_UserID_{}'.format(custom_assignments['BPG_APPLICATION_ID'], custom_assignments['ALTERNATE_USER_ID'])] = "{}|{}||{}|FALSE|{}".format(
                                        custom_assignments['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)
                                    extension_attributes_data[custom_assignments['EXTENSION_ATTRIBUTE_NAME']] = ""
                                    if custom_assignments['APPLICATION_CODE'] in ['FA','ILERPT'] and tms_extattr_added == 'N':
                                        printlog('custom_assigments match to '+custom_assignments['APPLICATION_CODE'])
                                        printlog('removing extension_attributes_data of value '+custom_assignments_tms['EXTENSION_ATTRIBUTE_NAME'])
                                        extension_attributes_data[custom_assignments_tms['EXTENSION_ATTRIBUTE_NAME']] = ""  

        #Special Handling for CLEAR
            if ((clear_trm_ext_attr_name in extension_attributes_data and '|FALSE|' in extension_attributes_data[clear_trm_ext_attr_name] and clear_supplier_ext_attr_name in extension_attributes_data and  '|FALSE|' in extension_attributes_data[clear_supplier_ext_attr_name]) or (clear_supplier_ext_attr_name in extension_attributes_data and  '|FALSE|' in extension_attributes_data[clear_supplier_ext_attr_name] and clear_trm_ext_attr_name not in extension_attributes_data)):
                groups_to_remove.append(clear_group_name) 
                try:               
                    printlog("Inactivate Supplier User -------")
                    cls_supplier_details_upd = {}
                    supplier_result_upd = {}
                    cls_supplier_details_upd = fetch_supplier(supplier_group_details['SCAC'], 'SCAC')
                    print ("fetch_supplier statusCode: "+str(cls_supplier_details_upd['statusCode']))                        
                    if cls_supplier_details_upd['statusCode'] == 200:
                       supplier_result_upd ['clsj1Id'] = cls_supplier_details_upd['j1Id']
                       supplier_result_upd ['clserpNum'] = cls_supplier_details_upd['erpNumber']
                       supplier_result_upd ['userCreated'] = "Y"
                       supplier_result_upd ['clsapexId'] = cls_supplier_details_upd['apexSupplierNumber']
                       csuapi_response_upd = create_supuser_upsert(supplier_result_upd['clserpNum'], supplier_result_upd['clsj1Id'], False, request.POST['first_name'], request.POST['last_name'],request.POST['work_email'])
                       print('Inactivate Supplier User ------ Upsert API Response')
                       print(csuapi_response_upd)
                except Exception as e:
                       printlog("Exception while calling CLS API Supplier User Upsert To Inactive User- "+str(e))                   


            if clear_supplier_ext_attr_name in extension_attributes_data:
                if staf_ext_attr_name not in extension_attributes_data and staf_group_name in user_group_list:
                   printlog("staf ext attribute set: " + staf_ext_attr_name)
                   extension_attributes_data[staf_ext_attr_name] = "{}|{}||{}|TRUE|{}".format(get_custom_assignments(ext_json_data,"STAF")['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)
                else:
                    if staf_ext_attr_name not in extension_attributes_data and staf_group_name not in user_group_list:
                       printlog("clear old ext attribute set: " + clear_supplier_old_ext_attr_name)
                       extension_attributes_data[clear_supplier_old_ext_attr_name] = ""

            if staf_ext_attr_name in extension_attributes_data:
                if clear_supplier_ext_attr_name not in extension_attributes_data and clear_group_name in user_group_list:
                   extension_attributes_data[clear_supplier_ext_attr_name] = "{}|{}||{}|TRUE|{}".format(get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)
                else:
                    if clear_supplier_ext_attr_name not in extension_attributes_data and clear_group_name not in user_group_list:
                       extension_attributes_data[staf_old_ext_attr_name] = ""
                    

            if clear_supplier_ext_attr_name in extension_attributes_data and '|FALSE|' in extension_attributes_data[clear_supplier_ext_attr_name]:
                if staf_ext_attr_name not in extension_attributes_data and staf_group_name not in user_group_list:
                   extension_attributes_data[clear_supplier_old_ext_attr_name] = ""
                else:
                     if staf_ext_attr_name not in extension_attributes_data and staf_group_name in user_group_list:
                        extension_attributes_data[staf_ext_attr_name] = "{}|{}||{}|TRUE|{}".format(get_custom_assignments(ext_json_data,"STAF")['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)                                             

            if staf_ext_attr_name in extension_attributes_data and '|FALSE|' in extension_attributes_data[staf_ext_attr_name]:
                if clear_supplier_ext_attr_name not in extension_attributes_data and clear_group_name not in user_group_list:
                   extension_attributes_data[staf_old_ext_attr_name] = ""
                else:
                     if clear_supplier_ext_attr_name not in extension_attributes_data and clear_group_name in user_group_list:
                        extension_attributes_data[clear_supplier_ext_attr_name] = "{}|{}||{}|TRUE|{}".format(get_custom_assignments(ext_json_data,"CLEAR_SUPPLIER")['APPLICATION_CODE'], guid, request.POST.get('company'), supplier_id)                                             

        
        # Setting Extension Attribute and Group Name of the fields from JSON file
            print("******EXISTING GROUPS*****")
            print(user_group_list)
            print("*******ADD GROUP********")
            print(groups_to_add)
            print("**********REM GROUP*******")
            print(groups_to_remove)
            print("*****EXTENSION ATTRIBUTES DATA*****")
            print(extension_attributes_data)
            print("************")

            if len(groups_to_add) > 0:
                groups_assign_to_user(
                    groups_to_add, request.POST.get('user_id'), access_token)
            if len(groups_to_remove) > 0:
                groups_unassign_to_user(
                    groups_to_remove, request.POST.get('user_id'), access_token)
            if (extension_attributes_data):
                update_extension_attributes(request.POST.get(
                    'user_id'), extension_attributes_data, access_token)
            
            invitation_access_token = fetch_invitation_access_token()
            add_user_to_administrative_unit(unit_name=settings.ADMINISTRATIVE_UNIT_NAME, user_id=request.POST.get('user_id'), access_token=invitation_access_token)
            
            #context = {'form': form}
            validation_error = 'User attributes have been updated. Please requery to see changes.'
            return HttpResponse(validation_error, content_type="text/plain", status=200)
        else:

            printlog(form.errors)

    return render(request, 'useraccesscontrolform.html', context)


def get_user_register_app_form(request):
    setlogenv(request)
    printlog("In get_user_register_app_form")
    isSuppAdmin = request.GET.get('suppadmin','N')
    printlog("AAAAAA")
    printlog(request.POST)
    printlog('(SupplierAdminValue)=>'+isSuppAdmin)
    if request.method == 'GET':        
        if isSuppAdmin == 'Y':
            printlog('Using SupplierAdminForm')
            form = UserRegisterAppSuppForm()
        else:
            printlog('Using RegularForm')
            form = UserRegisterAppForm()            
        context = {
            'form': form        
        }
        return render(request, 'useraccesscontrolform.html', context)
    elif request.method == 'POST':
        printlog("AAAAAA-POST")
        printlog(request.POST)
        form = RegistrationForm(data=request.POST)  
        
        #search_form =   UserMgmtSearchForm(data=request.POST)
        if form.is_valid():
            printlog("Form Valid") 
            # Fetch the Access Token
            return(usermgmt(request))
