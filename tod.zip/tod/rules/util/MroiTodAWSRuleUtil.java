package mroi.oracle.apps.xxmro.tod.rules.util;

import oracle.apps.fnd.common.VersionInfo;
/*====================================================================================
|  Name:                MroiTodAWSRuleUtil.java
|  Object Type:         Java Class
|  Description:         AWS Rules Util
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
|
|
|
======================================================================================*/

public class MroiTodAWSRuleUtil {
   public static final String RCS_ID = 
	"$Header: MroiTodAWSRuleUtil.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";
	
	public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.rules.util");

    public static final String MROI_TOD_AWS_UOM_LOOKUP_TYPE = "MROI_OTL_TOD_AWS_UOM_CODES";
    public static final String MROI_TOD_AWS_PERIOD_LOOKUP_TYPE = "MROI_OTL_TOD_AWS_PERIOD_CODES";
    public static final String MROI_TOD_AWS_OPER_LOOKUP_TYPE = "MROI_OTL_TOD_AWS_OPER_CODES";
    public static final String MROI_TOD_AWS_EMP_SCHED_LOOKUP_TYPE = "NZ_STATS_NZ_WORKING_TIME";
    public static final String MROI_TOD_AWS_RULE_SEQ_NAME = "MROI_OTL_TOD_AWS_RULES_S";
    public static final String MROI_TOD_AWS_RULE_ASGMTS_SEQ_NAME = "MROI_OTL_TOD_AWS_RULE_ASGMTS_S";
    public static final String MROI_TOD_AWS_RULE_STATUS_ACTIVE = "Active";
    public static final String MROI_TOD_AWS_RULE_PARAM_SUCCESS_MSG = "SuccessMsg";

}
