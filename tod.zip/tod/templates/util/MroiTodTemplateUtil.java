package mroi.oracle.apps.xxmro.tod.templates.util;
import oracle.apps.fnd.common.VersionInfo;

/** Util Class for common Constants and methods.
*/
public class MroiTodTemplateUtil {
	
	public static final String RCS_ID = 
	"$Header: MroiTodTemplateUtil.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";

  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.templates.util");

    public static final String MROI_TOD_TEMPLATE_STATUS_ACTIVE = "Active";
    public static final String MROI_TOD_TEMPLATE_PARAM_SUCCESS_MSG = "SuccessMsg";
    public static final String MROI_TOD_TEMPLATE_ID_SEQ_NAME = "MROI_OTL_TOD_TEMPLATES_S";
}
