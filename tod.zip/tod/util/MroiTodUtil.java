package mroi.oracle.apps.xxmro.tod.util;
/*====================================================================================
|  Name:                MroTodUtil.java
|  Object Type:         Java Class
|  Description:         
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
| 06/16/2026   MVP6    Kishore Murari            1.01   16064 - Changes to handle Night Shift & Shift Code  
|  
|  
|  
======================================================================================*/

import oracle.apps.fnd.common.VersionInfo;

import oracle.apps.fnd.framework.OAException;
import oracle.jbo.domain.Number;

public class MroiTodUtil {
	public static final String RCS_ID = 
	"$Header: MroiTodUtil.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";
	
	public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.util");

    public static final String MROI_TOD_SCHED_TYPE_LOOKUP_TYPE = "MROI_OTL_TOD_SCHEDULE_TYPES";
    public static final String MROI_TOD_AWS_TYPE_LOOKUP_TYPE = "MROI_OTL_TOD_AWS_CODE";
    public static final String MROI_TOD_SHIFT_TYPE_LOOKUP_TYPE = "MROI_OTL_TOD_SHIFT_CODE";
    public static final String MROI_TOD_YES_NO_LOOKUP_TYPE = "AWT_YES_NO";
    public static final String MROI_TOD_TIME_ATT_STATUS = "MROI_OTL_TOD_TIME_ATT_STATUS";
    public static final String MROI_TOD_STATUS_WORKING = "WORKING";
    public static final String MROI_TOD_STATUS_APPROVED = "APPROVED";
    public static final String MROI_TOD_PARAM_SUCCESS_MSG = "SuccessMsg";
    public static final String MROI_TOD_PARAM_ERROR_MSG = "ErrorMsg";
    public static final String MROI_TOD_PARAM_PERSON_ID = "PersonId";
    public static final String MROI_TOD_PARAM_TIME_PERIOD_ID = "TimePeriodId";
    public static final String MROI_TOD_GRADED = "G";
    public static final String MROI_TOD_UNGRADED = "U";
    public static final String MROI_TOD_SCHED_TYPE_HOURS = "Hours";
    public static final String MROI_TOD_SCHED_TYPE_TIME = "Time";
    public static final String MROI_TOD_SCHED_TYPE_SHIFT = "Shift";
    public static final String MROI_TOD_SCHED_TYPE_NIGHT = "Night";
    public static final String MROI_TOD_SCHED_TYPE_STOP = "Stop";
    public static final String MROI_TOD_WORK_SCHED_FULL = "F";
    public static final String MROI_TOD_WORK_SCHED_PART = "P";
    public static final String MROI_TOD_TIME_ATT_STATUS_ACTIVE = "A";
    public static final double MROI_TOD_FULL_TIME_MAX_HOURS = 80;
    public static final double MROI_TOD_PART_TIME_MAX_HOURS = 64;
    public static final double MROI_TOD_NIGHT_TIME_HOURS_START = 18;
    public static final int MROI_TOD_MID_NIGHT_STOP_HOUR = 24;
    public static final String MROI_TOD_APPROVED_STATUS_COLOR_CSS = "XXMroiTODApprStatusStyle";//"TouchScreenGreenCell";
    public static final String MROI_TOD_WORKING_STATUS_COLOR_CSS = "TouchScreenBlueBG"; //TouchScreenYellowCell";
    public static final String MROI_TOD_END_TIME_SUN_PAY = "00:00";
    public static final int MROI_TOD_SHIFT_TIME_DELTA_HOURS = 4;
    public static final String MROI_TOD_EMP_TYPE_US = "US";
    public static final String SCHEDULE_TYPE_SHIFT_CODE = "3";

	/**
	* Parses a time string in HH:mm format and returns the
	* corresponding hours and minutes values.
	*	
	* @param timing Time value in HH:mm format.
	* @return An integer array containing hours and minutes,
	*         or null if the input is invalid.
	*/

    public static int[] getHoursMinsFromTime(String timing) {

        if(timing == null)
           return null;
           
        if(timing.length() != 5 || timing.indexOf(':') != 2) {
           return null;
        }
        
        int[] intArr = new int[2];
        String[] timeArr = timing.split(":");
        try {
             intArr[0] = Integer.parseInt(timeArr[0]);
             intArr[1] = Integer.parseInt(timeArr[1]);

             if(intArr[0] < 0 || intArr[0] > 23 || intArr[1] < 0 || intArr[1] > 59)
                return null;
        } catch(NumberFormatException ex) {
            intArr =  null;
        }
        
        return intArr;
    }
	
	/**
	* Converts a numeric time value into HH:mm format.
	*
	* @param startTime Time value in HHmm format.
	* @return Formatted time in HH:mm format, a predefined value for
	*         midnight, or null if the input is null.
	*/
    
    public static String getFormattedTime(Number startTime) {
        String strStartTime = null;
        if(startTime != null) {
        
            strStartTime =  startTime.toString();
            if(startTime.intValue() == 0) {
                return MROI_TOD_END_TIME_SUN_PAY;
            } else if(startTime.intValue() < 1000) 
                strStartTime = "0" + strStartTime;
                
            if(strStartTime.length() == 4) {
                strStartTime = strStartTime.substring(0, 2) + ":" + strStartTime.substring(2);
            }  
          
        }
        return strStartTime;
    }
    
	/**
	* Determines whether the specified time is greater than or equal
	* to the given limit time.
	*
	* @param limitTimeStr Minimum allowable time in HH:mm format.
	* @param timeStr Time to compare in HH:mm format.
	* @return true if the specified time is greater than or equal to
	*         the limit time; otherwise false.
	*/
   public static boolean isTimeGreaterThan(String limitTimeStr, String timeStr) {
       boolean returnStatus = true;
       if(timeStr == null || limitTimeStr == null)
          return returnStatus;
          
       int [] limitTimeArr = getHoursMinsFromTime(limitTimeStr);
       int [] timeArr = getHoursMinsFromTime(timeStr);
       
       int timeHours = timeArr[0];
           
       if (limitTimeArr[0] > 
           timeHours || 
           (limitTimeArr[0] == 
            timeHours && 
            limitTimeArr[1] > 
            timeArr[1]))
              returnStatus = false;
       
       return returnStatus;
   }
   
   /**
	* Validates that the specified time is not later than the
	* provided limit time.
	*
	* @param limitTimeStr Upper bound time in HH:mm format.
	* @param timeStr Time to validate in HH:mm format.
	* @return true if the specified time is equal to or earlier than
	*         the limit time; otherwise false.
	*/
   
    public static boolean isTimeLessThan(String limitTimeStr, String timeStr) {
    
        boolean returnStatus = true;
        if(timeStr == null || limitTimeStr == null)
           return returnStatus;
        
        int [] limitTimeArr = getHoursMinsFromTime(limitTimeStr);
        int [] timeArr = getHoursMinsFromTime(timeStr);
        int timeHours = timeArr[0];

            
        if ( 
            limitTimeArr[0] < 
            timeHours || 
            (limitTimeArr[0] == 
             timeHours && 
             limitTimeArr[1] < 
             timeArr[1]))
               returnStatus = false;
        
        return returnStatus;
    }
    
	/**
	 * Validates whether the specified time falls within the given
	 * time range.
	 *
	 * @param fromTimeStr Start time of the range in HH:mm format.
	 * @param toTimeStr End time of the range in HH:mm format.
	 * @param timeStr Time to validate in HH:mm format.
	 * @return true if the specified time falls within the range or
	 *         if any input time is invalid; otherwise false.
	 */
 
    public static boolean isTimeInBetween(String fromTimeStr, String toTimeStr, String timeStr) {
        int [] fromTimeArr = getHoursMinsFromTime(fromTimeStr);
        int [] toTimeArr = getHoursMinsFromTime(toTimeStr);
        int [] timeArr = getHoursMinsFromTime(timeStr);
        
        if(fromTimeArr == null || toTimeArr == null || timeArr == null)
            return true;
            
        return isTimeInBetween(fromTimeArr, toTimeArr, timeArr);
    }
	/**
	 * Determines whether the specified time falls within the
	 * provided time range.
	 *
	 * @param fromTimeArr Start time represented as
	 *                    [hour, minute].
	 * @param toTimeArr End time represented as
	 *                  [hour, minute].
	 * @param timeArr Time to validate represented as
	 *                [hour, minute].
	 * @return true if the specified time is within or equal to
	 *         the start and end times; otherwise false.
	 */
    
    public static boolean isTimeInBetween(int [] fromTimeArr, int [] toTimeArr, int []timeArr) {
        
        boolean returnStatus = true;
        int timeHours = timeArr[0];
            
        if (fromTimeArr[0] > 
            timeHours || 
            (fromTimeArr[0] == 
             timeHours && 
             fromTimeArr[1] > 
             timeArr[1]) || 
            toTimeArr[0] < 
            timeHours || 
            (toTimeArr[0] == 
             timeHours && 
             toTimeArr[1] < 
             timeArr[1]))
               returnStatus = false;
        
        return returnStatus;
    }

}
