package mroi.oracle.apps.xxmro.tod.webui;
/*====================================================================================
|  Name:                MroiTodCreateUpdatePGCO.java
|  Object Type:         Java Class
|  Description:         TOD Create/Update Page Controller
|  Calls:               N/A
|
|  RICE Type:           Extension
|  RICE ID:             0147
|
|  Change History:
|  Date         MVP#    Name                      Ver    Modification
|  -----------  ----    ----------------------    ----   -------------
| 05/27/2026   MVP6    Kishore Murari            1.00   16053 - Initial creation for TOD
|  
|  
|  
======================================================================================*/

import java.io.Serializable;

import mroi.oracle.apps.xxmro.tod.util.MroiTodUtil;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;

import oracle.cabo.ui.UIConstants;

/**
 * Controller for ...
 */
public class MroiTodCreateUpdatePGCO extends OAControllerImpl {
	public static final String RCS_ID = 
		"$Header: MroiTodCreateUpdatePGCO.java 1.00 05/27/2026 08:00:00 kmurari 16053 $";

    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "mroi.oracle.apps.xxmro.tod.webui");

    /**
     * Layout and page setup logic for a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        String successMsg = pageContext.getParameter(MroiTodUtil.MROI_TOD_PARAM_SUCCESS_MSG);
        
        if( successMsg != null) {
            OAException e = new OAException(successMsg, OAException.CONFIRMATION);
            pageContext.putDialogMessage(e);
            pageContext.removeParameter(MroiTodUtil.MROI_TOD_PARAM_SUCCESS_MSG);
        }
        

        String PersonIdStr =  pageContext.getParameter("PersonId");
        String TodIDStr =  pageContext.getParameter("TimePeriodId");
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        Serializable param[] = { PersonIdStr, TodIDStr };
        am.invokeMethod("initViewObjects", param);
        
        OAMessageStyledTextBean todStatusBean = (OAMessageStyledTextBean) webBean.findChildRecursive("TodSchStatus");
        OADataBoundValueViewObject cssObj = new OADataBoundValueViewObject(todStatusBean, "StatusColorCSS");
        todStatusBean.setAttributeValue(UIConstants.STYLE_CLASS_ATTR, cssObj);
    }

    /**
     * Procedure to handle form submissions for form elements in
     * a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {
        super.processFormRequest(pageContext, webBean);
        
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        String event = pageContext.getParameter(EVENT_PARAM);
        
        if (pageContext.getParameter("Search") != null) {
            pageContext.setForwardURL("OA.jsp?page=/mroi/oracle/apps/xxmro/tod/webui/MroiTodSearchPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
        } else if(pageContext.getParameter("Save") != null) {
            am.invokeMethod("save");
            pageContext.putParameter(MroiTodUtil.MROI_TOD_PARAM_SUCCESS_MSG, "Successfully saved TOD data.");
            pageContext.forwardImmediatelyToCurrentPage(null, true, "Y");
        } else if(pageContext.getParameter("Submit") != null) {
            am.invokeMethod("submit");
            pageContext.putParameter(MroiTodUtil.MROI_TOD_PARAM_SUCCESS_MSG, "Successfully submitted TOD data.");
            pageContext.forwardImmediatelyToCurrentPage(null, true, "Y");

        } else if("UpdateHours".equals(event)) {
            String rowReference = pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
            Serializable param[] = { rowReference };
            am.invokeMethod("handleHoursUpdate", param);
        } else if("UpdateShift".equals(event)) {
            String rowReference = pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
            Serializable param[] = { rowReference };
            am.invokeMethod("handleShiftUpdate", param);
        } else if("RotatingShiftIndiUpdate".equals(event)) {
            am.invokeMethod("handleRotatingShiftIndiUpdate");
        } else if("RepeatingShiftIndiUpdate".equals(event)) {
            am.invokeMethod("handleRepeatingShiftIndiUpdate");
        }
    }

}
